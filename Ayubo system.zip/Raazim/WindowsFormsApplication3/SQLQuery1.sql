use aayubo
select * from Vehicle
select * from package