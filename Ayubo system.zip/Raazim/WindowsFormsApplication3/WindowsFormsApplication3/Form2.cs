﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication3
{
    public partial class Form2 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-8AQ53BR\\SQLEXPRESS;Initial Catalog=aayubo;Integrated Security=True");
        public Form2()
        {
            InitializeComponent();
        }




        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string sqlsearch;
            sqlsearch = "select *from Package where Package_ID= '" + txt_package_id.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlsearch, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                txt_package_id.Text = dr["Package_ID"].ToString();
                txt_package_type.Text = dr["Package_Types"].ToString();
                txt_package_rate.Text = dr["Package_Rate"].ToString();
                txt_vehicle_type.Text = dr["Vehicle_Type"].ToString();
                txt_maximum_km.Text = dr["Max_Km"].ToString();
                txt_maximum_hours.Text = dr["Max_Hrs"].ToString();
                txt_extra_km_rate.Text = dr["Extra_Km_Rate"].ToString();
                txt_extra_hours_rate.Text = dr["Extra_Hrs_Rate"].ToString();
                txt_driver_night_rate.Text = dr["Driver_Night_Rate"].ToString();
                txt_vehicle_night_rate.Text = dr["Vehicle_Night_Rate"].ToString();

            }
            else
            {
                MessageBox.Show("Package not found");
               // Clear_controls();
            }
            con.Close();
        
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            string sqlupdate;
            sqlupdate = "update Package set Package_ID= '" + txt_package_id.Text + "', Package_Types= '" + txt_package_type.Text + "' ,Package_Rate ='" + txt_package_rate.Text +
                "',Vehicle_Type='" + txt_vehicle_type.Text + "', Max_Km='" + txt_maximum_km.Text + "',Max_Hrs='" + txt_maximum_hours.Text + "',Extra_Km_Rate='" + txt_extra_km_rate.Text + 
                "',Extra_Hrs_Rate='" + txt_extra_hours_rate.Text + "',Driver_Night_Rate='" + txt_driver_night_rate.Text + "',Vehicle_Night_Rate='" + txt_vehicle_night_rate.Text + 
                "' where Package_ID = '" + txt_package_id.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlupdate, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record updated succesfull");
            //Clear_controls();
            con.Close();
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            string sqlInsert;
            sqlInsert = "Insert into Package(Package_ID, Package_Types,Package_Rate,Vehicle_Type,Max_Km,Max_Hrs,Extra_Km_Rate,Extra_Hrs_Rate,Driver_Night_Rate,Vehicle_Night_Rate) values ('"
                + txt_package_id.Text + "', '" + txt_package_type.Text + "','" + txt_package_rate.Text + "','" + txt_vehicle_type.Text + "','" + txt_maximum_km.Text + "','" 
                + txt_maximum_hours.Text + "','" + txt_extra_km_rate.Text + "','" + txt_extra_hours_rate.Text + "','" + txt_driver_night_rate.Text + "','" + txt_vehicle_night_rate.Text + "')";
            SqlCommand cmd = new SqlCommand(sqlInsert, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("RECORD INSERTED SUCCESSFULLY");
            //Clear_controls();
            con.Close();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DialogResult answer;
            answer = MessageBox.Show("DO YOU WANT TO DELETE THIS RECORD ?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer == DialogResult.Yes)
            {
                string sqldelete;
                sqldelete = "delete from Package where Package_ID='" + txt_package_id.Text + "'";
                SqlCommand cmd = new SqlCommand(sqldelete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Package Details delete");
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            DialogResult msg = MessageBox.Show("DO YOU WANT TO CLOSE THIS INTERFACE ?", "close", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DialogResult.Yes == msg)
            {
                Application.Exit();
            }
        }
    }
}
