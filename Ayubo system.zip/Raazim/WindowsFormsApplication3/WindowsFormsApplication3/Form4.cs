﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication3
{
    public partial class Form4 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-8AQ53BR\\SQLEXPRESS;Initial Catalog=aayubo;Integrated Security=True");
        public Form4()
        {
            InitializeComponent();
        }

        private void package_details_Enter(object sender, EventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string sqlsearch;
            sqlsearch = "select *from Package where Package_ID= '" + txt_package_id.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlsearch, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {

                txt_package_id.Text = dr["Package_ID"].ToString();
                txt_package_type.Text = dr["package_Types"].ToString();
                txt_package_rate.Text = dr["Package_Rate"].ToString();
                txt_maximum_km.Text = dr["Max_Km"].ToString();
                txt_maximum_hours.Text = dr["Max_Hrs"].ToString();
                txt_extra_hours_rate.Text = dr["Extra_hrs_rate"].ToString();
                txt_extra_km_rate.Text = dr["Extra_Km_rate"].ToString();
            }
            else
            {
                MessageBox.Show("Package_ID Not Found");
               // Clear_controls();
            }
            con.Close();

        }

        private void btn_calculate_hours_Click(object sender, EventArgs e)
        {
            DateTime Start_time, End_time;
            TimeSpan ts;
            double total_hours, Extra_hours_charge, Extra_hours_rate;
            int Number_of_hours, maximum_hours, Extra_hours;

            Start_time = DateTime.Parse(start_time_date_time_picker.Text);
            End_time = DateTime.Parse(end_time_date_time_picker.Text);
            ts = End_time - Start_time;
            total_hours = ts.Hours;

            if (total_hours>0)
            {
                txt_number_of_hours.Text = total_hours.ToString();
            }
            else
            {
                MessageBox.Show("invalid time");
            }
            
            Number_of_hours = int.Parse(txt_number_of_hours.Text);
            maximum_hours = int.Parse(txt_maximum_hours.Text);
            if (maximum_hours < Number_of_hours)
            {
                Extra_hours = Number_of_hours - maximum_hours;
            }

            else
            {
                Extra_hours = 0;
            }

            txt_extra_hours.Text = Extra_hours.ToString();
            Extra_hours_rate = double.Parse(txt_extra_hours_rate.Text);
            Extra_hours_charge = Extra_hours * Extra_hours_rate;
            {
                txt_extra_hours_charge.Text = Extra_hours_charge.ToString();
            }
        }

        private void btn_calculate_km_Click(object sender, EventArgs e)
        {
            double Extra_km_rate;
            int start_km, end_km, number_of_km, maximum_km, Extra_Km;
            start_km = int.Parse(txt_start_km_reading.Text);
            end_km = int.Parse(txt_end_km_reading.Text);
            number_of_km = end_km - start_km;
            txt_number_of_km.Text = number_of_km.ToString();
            maximum_km = int.Parse(txt_maximum_km.Text);
            if (maximum_km < number_of_km)
            {
                Extra_Km = number_of_km - maximum_km;
            }
            else
            {
                Extra_Km = 0;
            }
            txt_extra_km.Text = Extra_Km.ToString();
            Extra_km_rate = double.Parse(txt_extra_km_rate.Text);
            Extra_km_rate = Extra_Km * Extra_km_rate;
            {
                txt_extra_km_charge.Text = Extra_km_rate.ToString();
            }
        }

        private void btn_calculate_day_hire_Click(object sender, EventArgs e)
        {
            double Package_Rate, Extra_Hours_Charge, Extra_Km_Charge, total_cost;
            Package_Rate = double.Parse(txt_package_rate.Text);
            Extra_Hours_Charge = double.Parse(txt_extra_hours_charge.Text);
            Extra_Km_Charge = double.Parse(txt_extra_km_charge.Text);
            total_cost = Package_Rate + Extra_Km_Charge + Extra_Hours_Charge;
            {
                txt_total_cost.Text = total_cost.ToString();
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            DialogResult msg = MessageBox.Show("DO YOU WANT TO CLOSE THIS INTERFACE ?", "close", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DialogResult.Yes == msg)
            {
                Application.Exit();
            }
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
