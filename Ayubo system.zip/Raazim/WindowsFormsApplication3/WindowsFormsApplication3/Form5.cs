﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication3
{


    public partial class Form5 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-8AQ53BR\\SQLEXPRESS;Initial Catalog=aayubo;Integrated Security=True");
        public Form5()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string sqlsearch;
            sqlsearch = "select *from Package where Package_ID= '" + txt_package_id.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlsearch, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                txt_package_id.Text = dr["Package_ID"].ToString();
                txt_package_type.Text = dr["Package_Types"].ToString();
                txt_package_rate.Text = dr["Package_Rate"].ToString();
                txt_vehicle_type.Text = dr["Vehicle_Type"].ToString();
                txt_maximum_km.Text = dr["Max_Km"].ToString();
                txt_extra_km_rate.Text = dr["Extra_Km_Rate"].ToString();
                txt_driver_night_rate.Text = dr["Driver_Night_Rate"].ToString();
                txt_vehicle_night_rate.Text = dr["Vehicle_Night_Rate"].ToString();


            }
        }

        private void btn_calculate_days_Click(object sender, EventArgs e)
        {
            DateTime Rented_Date, Reaturned_Date;
            TimeSpan ts;
            int total_Days;

            Rented_Date = DateTime.Parse(rented_date_time_picker.Text);
            Reaturned_Date = DateTime.Parse(returned_date_time_picker.Text);
            ts = Reaturned_Date - Rented_Date;
            total_Days = ts.Days;

            txt_total_days.Text = total_Days.ToString();

           
        }

        private void btn_calculate_long_hire_Click(object sender, EventArgs e)
        {
            DateTime rented, returned;
            TimeSpan ts;
            Double tot_days;

            rented = DateTime.Parse(rented_date_time_picker.Text);
            returned = DateTime.Parse(returned_date_time_picker.Text);
            ts = returned - rented;

            tot_days = ts.Days;

            double totp_rate = ts.Days * (double.Parse(txt_package_rate.Text));
            txt_total_package_rate.Text = totp_rate.ToString();

            double extotKMcharge = (int.Parse(txt_extra_km.Text)) * (double.Parse(txt_extra_km_rate.Text));
            txt_extra_km_charge_2.Text = extotKMcharge.ToString();

            double tot_v_night_rate = ((ts.Days - 1) * (double.Parse(txt_vehicle_night_rate.Text)));
            txt_toto_v_night_ratee.Text = tot_v_night_rate.ToString();

            double tot_driver_night_rate = ((ts.Days - 1) * (double.Parse(txt_driver_night_rate.Text)));
            txt_tot_driver_night_rate.Text = tot_driver_night_rate.ToString();

            double tot_cost = totp_rate +   (int.Parse(txt_extra_km_charge.Text))+tot_v_night_rate+ tot_driver_night_rate;
            txt_total_cost.Text = tot_cost.ToString();
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_package_id.Clear();
            txt_package_type.Clear();
            txt_package_rate.Clear();
            txt_total_package_rate.Clear();
            txt_vehicle_type.Clear();
            txt_maximum_km.Clear();
            //txt_total_maximum_km.Clear();
            txt_extra_km_rate.Clear();
            txt_driver_night_rate.Clear();
            txt_vehicle_night_rate.Clear();
            txt_start_km_reading.Clear();
            txt_end_km_reading.Clear();
            txt_number_of_km.Clear();
            txt_extra_km.Clear();
            txt_extra_km_charge.Clear();
            txt_total_days.Clear();
            txt_total_cost.Clear();
           // txt_total_night_cost.Clear();
        }

        private void btn_calculate_km_Click(object sender, EventArgs e)
        {
            DateTime rented, returned;
            TimeSpan ts;
            Double tot_days;

            rented = DateTime.Parse(rented_date_time_picker.Text);
            returned = DateTime.Parse(returned_date_time_picker.Text);
            ts = returned - rented;

            tot_days = ts.Days;

            int stKM_R = int.Parse(txt_start_km_reading.Text);
            int endKM_R = int.Parse(txt_end_km_reading.Text);

            int noKM = endKM_R - stKM_R;
            txt_number_of_km.Text = noKM.ToString();

            int totmaxKM = ts.Days * (int.Parse(txt_maximum_km.Text));
            txt_tot_max_km.Text = totmaxKM.ToString();

            int exKM = noKM - totmaxKM;
            txt_extra_km.Text = exKM.ToString();



            double extotKMcharge = exKM * (double.Parse(txt_extra_km_rate.Text));
            txt_extra_km_charge.Text = extotKMcharge.ToString();
        }

        private void groupBox4_Enter(object sender, EventArgs e)
        {

        }

        private void txt_toto_v_night_rate_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
