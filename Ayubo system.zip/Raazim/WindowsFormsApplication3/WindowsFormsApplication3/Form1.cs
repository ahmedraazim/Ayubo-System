﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-8AQ53BR\\SQLEXPRESS;Initial Catalog=aayubo;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string sqlsearch;
            sqlsearch = "select * from  Vehicle where Vehicle_Number='" + txt_Vehicle_Number.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlsearch, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {

                txt_Vehicle_Number.Text = dr["Vehicle_Number"].ToString();
                txt_vehicle_types.Text = dr["Vehicle_Types"].ToString();
                txt_vehicle_models.Text = dr["Vehicle_Models"].ToString();
                txt_rate_per_day.Text = dr["Rate_Per_Day"].ToString();
                txt_rate_per_week.Text = dr["Rate_Per_Week"].ToString();
                txt_Rate_Per_Month.Text = dr["Rate_Per_Month"].ToString();
                txt_driver_rate.Text = dr["Driver_Rate"].ToString();

            }
            else
            {
                MessageBox.Show("Invalid Vehicle Number");
                //Clear_controls();
            }
            con.Close();
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            string sqlInsert;
            sqlInsert = "Insert into Vehicle (Vehicle_Number,Vehicle_Types,Vehicle_Models,Rate_Per_Day,Rate_Per_Week,Rate_Per_Month,Driver_Rate) values ('" 
                + txt_Vehicle_Number.Text + "','" + txt_vehicle_types.Text + "', '" + txt_vehicle_models.Text + "','" + txt_rate_per_day.Text + "','" + txt_rate_per_week.Text +
                "','" + txt_Rate_Per_Month.Text + "','" + txt_Rate_Per_Month.Text + "' )";
            SqlCommand cmd = new SqlCommand(sqlInsert, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Inserted");
            //Clear_controls();
            con.Close();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DialogResult answer;
            answer = MessageBox.Show("do you want to delete this record ?", "delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (answer == DialogResult.Yes)
            {
                string sqldelete;
                sqldelete = "delete from  Vehicle where Vehicle_Number='" + txt_Vehicle_Number.Text + "' ";
                SqlCommand cmd = new SqlCommand(sqldelete, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Vehicle Details deleted");
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            string sqlupdate;
            sqlupdate = "update Vehicle set Vehicle_Number = '" + txt_Vehicle_Number.Text + "', Vehicle_Types ='" + txt_vehicle_types.Text +
                        "', Vehicle_Models = '" + txt_vehicle_models.Text + "', Rate_Per_Day ='" + txt_rate_per_day.Text + "', Rate_Per_Week = '" + txt_rate_per_week.Text +
                        "', Rate_Per_Month='" + txt_Rate_Per_Month.Text + "',Driver_Rate='" + txt_driver_rate.Text + "' where vehicle_Number = '" + txt_Vehicle_Number.Text + "'";
            SqlCommand cmd = new SqlCommand(sqlupdate, con);
            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Record Updated Succesfully", "Update", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            //Clear_controls();
            con.Close();
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            DialogResult msg = MessageBox.Show("do you want to close this interface ?", "close", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (DialogResult.Yes == msg)
            {
                Application.Exit();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
