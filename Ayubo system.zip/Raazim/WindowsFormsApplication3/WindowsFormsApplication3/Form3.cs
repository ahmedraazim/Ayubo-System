﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication3
{
    public partial class Form3 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-8AQ53BR\\SQLEXPRESS;Initial Catalog=aayubo;Integrated Security=True");

        public Form3()
        {
            InitializeComponent();
        }



        private void btn_search_Click(object sender, EventArgs e)
        {
            string sqlsearch;
            sqlsearch = "select * from  Vehicle where Vehicle_Number='" + txt_vehicle_number.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlsearch, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {

                txt_vehicle_number.Text = dr["Vehicle_Number"].ToString();
                txt_vehicle_type.Text = dr["Vehicle_Types"].ToString();
                txt_vehicle_models.Text = dr["Vehicle_Models"].ToString();
                txt_rate_per_day.Text = dr["Rate_Per_Day"].ToString();
                txt_rate_per_week.Text = dr["Rate_Per_Week"].ToString();
                txt_rate_per_month.Text = dr["Rate_Per_Month"].ToString();
                txt_driver_rate.Text = dr["Driver_Rate"].ToString();

            }
            else
            {
                MessageBox.Show("Invalid Vehicle Number");
                //Clear_controls();
            }
            con.Close();


        }

        private void btn_calculate_days_Click(object sender, EventArgs e)
        {
            DateTime Rented, returnd;
            TimeSpan ts;
            double tot_days;
            int Total_days, month, week, reminder, days;

            Rented = DateTime.Parse(rented_date_time_picker.Text);
            returnd = DateTime.Parse(returned_date_time_picker.Text);
            ts = returnd - Rented;
            tot_days = ts.Days;
            txt_total_days.Text = tot_days.ToString();
            Total_days = int.Parse(txt_total_days.Text);
            month = Total_days / 30;
            reminder = Total_days % 30;
            week = reminder / 7;
            days = reminder % 7;

            txt_months.Text = month.ToString();
            txt_weeks.Text = week.ToString();
            txt_days.Text = days.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlsearch;
            sqlsearch = "select * from vehicle where vehicle_Number= '" + txt_vehicle_number.Text + "' ";
            SqlCommand cmd = new SqlCommand(sqlsearch, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)

            {
                int Tdays, month, week, days;
                Double D_rate, W_rate, M_rate, Dri_rate, total_cost;
                Tdays = int.Parse(txt_days.Text);
                D_rate = Double.Parse(txt_rate_per_day.Text);
                W_rate = Double.Parse(txt_rate_per_week.Text);
                M_rate = Double.Parse(txt_rate_per_month.Text);
                Dri_rate = Double.Parse(txt_driver_rate.Text);
                days = int.Parse(txt_days.Text);
                week = int.Parse(txt_weeks.Text);
                month = int.Parse(txt_months.Text);


                if (chk_with_driver.Checked == true)
                {
                    total_cost = Tdays * Dri_rate + month * M_rate + week * W_rate + days * D_rate;
                    txt_total_cost.Text = total_cost.ToString();
                }
                else
                {
                    total_cost = D_rate * days + W_rate * week + M_rate * month;
                    txt_total_cost.Text = total_cost.ToString();
                }

            }
            else
            {
                MessageBox.Show("vehicle not found");
                //Clear_controls();
            }
            con.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
