﻿namespace WindowsFormsApplication3
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.package_details = new System.Windows.Forms.GroupBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_vehicle_night_rate = new System.Windows.Forms.TextBox();
            this.txt_maximum_km = new System.Windows.Forms.TextBox();
            this.txt_driver_night_rate = new System.Windows.Forms.TextBox();
            this.txt_vehicle_type = new System.Windows.Forms.TextBox();
            this.txt_package_rate = new System.Windows.Forms.TextBox();
            this.txt_extra_km_rate = new System.Windows.Forms.TextBox();
            this.txt_package_type = new System.Windows.Forms.TextBox();
            this.txt_package_id = new System.Windows.Forms.TextBox();
            this.vehicle_night_rate = new System.Windows.Forms.Label();
            this.maximum_km = new System.Windows.Forms.Label();
            this.driver_night_rate = new System.Windows.Forms.Label();
            this.vehicle_type = new System.Windows.Forms.Label();
            this.extra_km_rate = new System.Windows.Forms.Label();
            this.package_rate = new System.Windows.Forms.Label();
            this.package_type = new System.Windows.Forms.Label();
            this.package_id = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.total_calculate = new System.Windows.Forms.GroupBox();
            this.txt_tot_driver_night_rate = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_toto_v_night_ratee = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_extra_km_charge_2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_calculate_long_hire = new System.Windows.Forms.Button();
            this.txt_total_cost = new System.Windows.Forms.TextBox();
            this.txt_total_package_rate = new System.Windows.Forms.TextBox();
            this.total_cost = new System.Windows.Forms.Label();
            this.total_package_rate = new System.Windows.Forms.Label();
            this.days = new System.Windows.Forms.GroupBox();
            this.btn_calculate_days = new System.Windows.Forms.Button();
            this.Total_days = new System.Windows.Forms.Label();
            this.txt_total_days = new System.Windows.Forms.TextBox();
            this.returned_date_time_picker = new System.Windows.Forms.DateTimePicker();
            this.rented_date_time_picker = new System.Windows.Forms.DateTimePicker();
            this.return_date = new System.Windows.Forms.Label();
            this.rented_date = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txt_tot_max_km = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_calculate_km = new System.Windows.Forms.Button();
            this.txt_extra_km_charge = new System.Windows.Forms.TextBox();
            this.extra_km_charge = new System.Windows.Forms.Label();
            this.txt_extra_km = new System.Windows.Forms.TextBox();
            this.extra_km = new System.Windows.Forms.Label();
            this.txt_number_of_km = new System.Windows.Forms.TextBox();
            this.txt_end_km_reading = new System.Windows.Forms.TextBox();
            this.txt_start_km_reading = new System.Windows.Forms.TextBox();
            this.number_of_km = new System.Windows.Forms.Label();
            this.end_km_reading = new System.Windows.Forms.Label();
            this.start_km_reading = new System.Windows.Forms.Label();
            this.drive_time = new System.Windows.Forms.Label();
            this.package_details.SuspendLayout();
            this.total_calculate.SuspendLayout();
            this.days.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // package_details
            // 
            this.package_details.Controls.Add(this.btn_search);
            this.package_details.Controls.Add(this.txt_vehicle_night_rate);
            this.package_details.Controls.Add(this.txt_maximum_km);
            this.package_details.Controls.Add(this.txt_driver_night_rate);
            this.package_details.Controls.Add(this.txt_vehicle_type);
            this.package_details.Controls.Add(this.txt_package_rate);
            this.package_details.Controls.Add(this.txt_extra_km_rate);
            this.package_details.Controls.Add(this.txt_package_type);
            this.package_details.Controls.Add(this.txt_package_id);
            this.package_details.Controls.Add(this.vehicle_night_rate);
            this.package_details.Controls.Add(this.maximum_km);
            this.package_details.Controls.Add(this.driver_night_rate);
            this.package_details.Controls.Add(this.vehicle_type);
            this.package_details.Controls.Add(this.extra_km_rate);
            this.package_details.Controls.Add(this.package_rate);
            this.package_details.Controls.Add(this.package_type);
            this.package_details.Controls.Add(this.package_id);
            this.package_details.Location = new System.Drawing.Point(31, 52);
            this.package_details.Name = "package_details";
            this.package_details.Size = new System.Drawing.Size(411, 304);
            this.package_details.TabIndex = 0;
            this.package_details.TabStop = false;
            this.package_details.Text = "package_details";
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Teal;
            this.btn_search.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(195, 261);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(94, 37);
            this.btn_search.TabIndex = 33;
            this.btn_search.Text = "search";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txt_vehicle_night_rate
            // 
            this.txt_vehicle_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_vehicle_night_rate.Location = new System.Drawing.Point(179, 210);
            this.txt_vehicle_night_rate.Name = "txt_vehicle_night_rate";
            this.txt_vehicle_night_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_vehicle_night_rate.TabIndex = 26;
            // 
            // txt_maximum_km
            // 
            this.txt_maximum_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maximum_km.Location = new System.Drawing.Point(179, 129);
            this.txt_maximum_km.Name = "txt_maximum_km";
            this.txt_maximum_km.Size = new System.Drawing.Size(147, 20);
            this.txt_maximum_km.TabIndex = 24;
            // 
            // txt_driver_night_rate
            // 
            this.txt_driver_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_driver_night_rate.Location = new System.Drawing.Point(179, 182);
            this.txt_driver_night_rate.Name = "txt_driver_night_rate";
            this.txt_driver_night_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_driver_night_rate.TabIndex = 28;
            // 
            // txt_vehicle_type
            // 
            this.txt_vehicle_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_vehicle_type.Location = new System.Drawing.Point(179, 104);
            this.txt_vehicle_type.Name = "txt_vehicle_type";
            this.txt_vehicle_type.Size = new System.Drawing.Size(147, 20);
            this.txt_vehicle_type.TabIndex = 25;
            // 
            // txt_package_rate
            // 
            this.txt_package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_rate.Location = new System.Drawing.Point(179, 76);
            this.txt_package_rate.Name = "txt_package_rate";
            this.txt_package_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_package_rate.TabIndex = 27;
            // 
            // txt_extra_km_rate
            // 
            this.txt_extra_km_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km_rate.Location = new System.Drawing.Point(179, 156);
            this.txt_extra_km_rate.Name = "txt_extra_km_rate";
            this.txt_extra_km_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_km_rate.TabIndex = 31;
            // 
            // txt_package_type
            // 
            this.txt_package_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_type.Location = new System.Drawing.Point(179, 51);
            this.txt_package_type.Name = "txt_package_type";
            this.txt_package_type.Size = new System.Drawing.Size(147, 20);
            this.txt_package_type.TabIndex = 30;
            // 
            // txt_package_id
            // 
            this.txt_package_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_id.Location = new System.Drawing.Point(179, 27);
            this.txt_package_id.Name = "txt_package_id";
            this.txt_package_id.Size = new System.Drawing.Size(147, 20);
            this.txt_package_id.TabIndex = 32;
            // 
            // vehicle_night_rate
            // 
            this.vehicle_night_rate.AutoSize = true;
            this.vehicle_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_night_rate.Location = new System.Drawing.Point(12, 210);
            this.vehicle_night_rate.Name = "vehicle_night_rate";
            this.vehicle_night_rate.Size = new System.Drawing.Size(156, 20);
            this.vehicle_night_rate.TabIndex = 21;
            this.vehicle_night_rate.Text = "vehicle_night_rate";
            // 
            // maximum_km
            // 
            this.maximum_km.AutoSize = true;
            this.maximum_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maximum_km.Location = new System.Drawing.Point(12, 126);
            this.maximum_km.Name = "maximum_km";
            this.maximum_km.Size = new System.Drawing.Size(116, 20);
            this.maximum_km.TabIndex = 20;
            this.maximum_km.Text = "maximum_km";
            // 
            // driver_night_rate
            // 
            this.driver_night_rate.AutoSize = true;
            this.driver_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driver_night_rate.Location = new System.Drawing.Point(12, 185);
            this.driver_night_rate.Name = "driver_night_rate";
            this.driver_night_rate.Size = new System.Drawing.Size(145, 20);
            this.driver_night_rate.TabIndex = 19;
            this.driver_night_rate.Text = "driver_night_rate";
            // 
            // vehicle_type
            // 
            this.vehicle_type.AutoSize = true;
            this.vehicle_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_type.Location = new System.Drawing.Point(12, 101);
            this.vehicle_type.Name = "vehicle_type";
            this.vehicle_type.Size = new System.Drawing.Size(108, 20);
            this.vehicle_type.TabIndex = 17;
            this.vehicle_type.Text = "vehicle_type";
            // 
            // extra_km_rate
            // 
            this.extra_km_rate.AutoSize = true;
            this.extra_km_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_km_rate.Location = new System.Drawing.Point(12, 155);
            this.extra_km_rate.Name = "extra_km_rate";
            this.extra_km_rate.Size = new System.Drawing.Size(124, 20);
            this.extra_km_rate.TabIndex = 16;
            this.extra_km_rate.Text = "extra_km_rate";
            // 
            // package_rate
            // 
            this.package_rate.AutoSize = true;
            this.package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_rate.Location = new System.Drawing.Point(12, 73);
            this.package_rate.Name = "package_rate";
            this.package_rate.Size = new System.Drawing.Size(119, 20);
            this.package_rate.TabIndex = 15;
            this.package_rate.Text = "package_rate";
            // 
            // package_type
            // 
            this.package_type.AutoSize = true;
            this.package_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_type.Location = new System.Drawing.Point(12, 48);
            this.package_type.Name = "package_type";
            this.package_type.Size = new System.Drawing.Size(121, 20);
            this.package_type.TabIndex = 22;
            this.package_type.Text = "package_type";
            // 
            // package_id
            // 
            this.package_id.AutoSize = true;
            this.package_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_id.Location = new System.Drawing.Point(12, 24);
            this.package_id.Name = "package_id";
            this.package_id.Size = new System.Drawing.Size(101, 20);
            this.package_id.TabIndex = 13;
            this.package_id.Text = "package_id";
            // 
            // total_calculate
            // 
            this.total_calculate.Controls.Add(this.txt_tot_driver_night_rate);
            this.total_calculate.Controls.Add(this.label4);
            this.total_calculate.Controls.Add(this.txt_toto_v_night_ratee);
            this.total_calculate.Controls.Add(this.label1);
            this.total_calculate.Controls.Add(this.txt_extra_km_charge_2);
            this.total_calculate.Controls.Add(this.label3);
            this.total_calculate.Controls.Add(this.btn_clear);
            this.total_calculate.Controls.Add(this.btn_calculate_long_hire);
            this.total_calculate.Controls.Add(this.txt_total_cost);
            this.total_calculate.Controls.Add(this.txt_total_package_rate);
            this.total_calculate.Controls.Add(this.total_cost);
            this.total_calculate.Controls.Add(this.total_package_rate);
            this.total_calculate.Location = new System.Drawing.Point(470, 52);
            this.total_calculate.Name = "total_calculate";
            this.total_calculate.Size = new System.Drawing.Size(411, 304);
            this.total_calculate.TabIndex = 1;
            this.total_calculate.TabStop = false;
            this.total_calculate.Text = "total_calculate";
            // 
            // txt_tot_driver_night_rate
            // 
            this.txt_tot_driver_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tot_driver_night_rate.Location = new System.Drawing.Point(231, 62);
            this.txt_tot_driver_night_rate.Name = "txt_tot_driver_night_rate";
            this.txt_tot_driver_night_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_tot_driver_night_rate.TabIndex = 54;
            this.txt_tot_driver_night_rate.TextChanged += new System.EventHandler(this.txt_toto_v_night_rate_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(176, 20);
            this.label4.TabIndex = 53;
            this.label4.Text = "total driver night rate";
            // 
            // txt_toto_v_night_ratee
            // 
            this.txt_toto_v_night_ratee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_toto_v_night_ratee.Location = new System.Drawing.Point(231, 88);
            this.txt_toto_v_night_ratee.Name = "txt_toto_v_night_ratee";
            this.txt_toto_v_night_ratee.Size = new System.Drawing.Size(147, 20);
            this.txt_toto_v_night_ratee.TabIndex = 52;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 20);
            this.label1.TabIndex = 51;
            this.label1.Text = "total vehicle night rate";
            // 
            // txt_extra_km_charge_2
            // 
            this.txt_extra_km_charge_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km_charge_2.Location = new System.Drawing.Point(231, 118);
            this.txt_extra_km_charge_2.Name = "txt_extra_km_charge_2";
            this.txt_extra_km_charge_2.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_km_charge_2.TabIndex = 50;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 20);
            this.label3.TabIndex = 49;
            this.label3.Text = "extra_km_charge";
            // 
            // btn_clear
            // 
            this.btn_clear.BackColor = System.Drawing.Color.Teal;
            this.btn_clear.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clear.Location = new System.Drawing.Point(264, 233);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(99, 37);
            this.btn_clear.TabIndex = 44;
            this.btn_clear.Text = "clear";
            this.btn_clear.UseVisualStyleBackColor = false;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_calculate_long_hire
            // 
            this.btn_calculate_long_hire.BackColor = System.Drawing.Color.Olive;
            this.btn_calculate_long_hire.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate_long_hire.Location = new System.Drawing.Point(6, 233);
            this.btn_calculate_long_hire.Name = "btn_calculate_long_hire";
            this.btn_calculate_long_hire.Size = new System.Drawing.Size(208, 37);
            this.btn_calculate_long_hire.TabIndex = 43;
            this.btn_calculate_long_hire.Text = "calculate_long_hire";
            this.btn_calculate_long_hire.UseVisualStyleBackColor = false;
            this.btn_calculate_long_hire.Click += new System.EventHandler(this.btn_calculate_long_hire_Click);
            // 
            // txt_total_cost
            // 
            this.txt_total_cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_cost.Location = new System.Drawing.Point(231, 157);
            this.txt_total_cost.Name = "txt_total_cost";
            this.txt_total_cost.Size = new System.Drawing.Size(147, 20);
            this.txt_total_cost.TabIndex = 39;
            // 
            // txt_total_package_rate
            // 
            this.txt_total_package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_package_rate.Location = new System.Drawing.Point(231, 29);
            this.txt_total_package_rate.Name = "txt_total_package_rate";
            this.txt_total_package_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_total_package_rate.TabIndex = 42;
            // 
            // total_cost
            // 
            this.total_cost.AutoSize = true;
            this.total_cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_cost.Location = new System.Drawing.Point(26, 153);
            this.total_cost.Name = "total_cost";
            this.total_cost.Size = new System.Drawing.Size(89, 20);
            this.total_cost.TabIndex = 35;
            this.total_cost.Text = "total_cost";
            // 
            // total_package_rate
            // 
            this.total_package_rate.AutoSize = true;
            this.total_package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.total_package_rate.Location = new System.Drawing.Point(19, 27);
            this.total_package_rate.Name = "total_package_rate";
            this.total_package_rate.Size = new System.Drawing.Size(165, 20);
            this.total_package_rate.TabIndex = 33;
            this.total_package_rate.Text = "total_package_rate";
            // 
            // days
            // 
            this.days.Controls.Add(this.btn_calculate_days);
            this.days.Controls.Add(this.Total_days);
            this.days.Controls.Add(this.txt_total_days);
            this.days.Controls.Add(this.returned_date_time_picker);
            this.days.Controls.Add(this.rented_date_time_picker);
            this.days.Controls.Add(this.return_date);
            this.days.Controls.Add(this.rented_date);
            this.days.Location = new System.Drawing.Point(31, 368);
            this.days.Name = "days";
            this.days.Size = new System.Drawing.Size(411, 196);
            this.days.TabIndex = 1;
            this.days.TabStop = false;
            this.days.Text = "days";
            // 
            // btn_calculate_days
            // 
            this.btn_calculate_days.BackColor = System.Drawing.Color.Olive;
            this.btn_calculate_days.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate_days.Location = new System.Drawing.Point(119, 125);
            this.btn_calculate_days.Name = "btn_calculate_days";
            this.btn_calculate_days.Size = new System.Drawing.Size(146, 37);
            this.btn_calculate_days.TabIndex = 28;
            this.btn_calculate_days.Text = "calculate_days";
            this.btn_calculate_days.UseVisualStyleBackColor = false;
            this.btn_calculate_days.Click += new System.EventHandler(this.btn_calculate_days_Click);
            // 
            // Total_days
            // 
            this.Total_days.AutoSize = true;
            this.Total_days.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_days.Location = new System.Drawing.Point(26, 94);
            this.Total_days.Name = "Total_days";
            this.Total_days.Size = new System.Drawing.Size(110, 24);
            this.Total_days.TabIndex = 27;
            this.Total_days.Text = "Total_days";
            // 
            // txt_total_days
            // 
            this.txt_total_days.Location = new System.Drawing.Point(233, 94);
            this.txt_total_days.Name = "txt_total_days";
            this.txt_total_days.Size = new System.Drawing.Size(147, 20);
            this.txt_total_days.TabIndex = 26;
            // 
            // returned_date_time_picker
            // 
            this.returned_date_time_picker.Location = new System.Drawing.Point(195, 56);
            this.returned_date_time_picker.Name = "returned_date_time_picker";
            this.returned_date_time_picker.Size = new System.Drawing.Size(200, 20);
            this.returned_date_time_picker.TabIndex = 24;
            // 
            // rented_date_time_picker
            // 
            this.rented_date_time_picker.Location = new System.Drawing.Point(195, 17);
            this.rented_date_time_picker.Name = "rented_date_time_picker";
            this.rented_date_time_picker.Size = new System.Drawing.Size(200, 20);
            this.rented_date_time_picker.TabIndex = 25;
            // 
            // return_date
            // 
            this.return_date.AutoSize = true;
            this.return_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_date.Location = new System.Drawing.Point(13, 54);
            this.return_date.Name = "return_date";
            this.return_date.Size = new System.Drawing.Size(116, 24);
            this.return_date.TabIndex = 22;
            this.return_date.Text = "return_date";
            // 
            // rented_date
            // 
            this.rented_date.AutoSize = true;
            this.rented_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rented_date.Location = new System.Drawing.Point(13, 15);
            this.rented_date.Name = "rented_date";
            this.rented_date.Size = new System.Drawing.Size(121, 24);
            this.rented_date.TabIndex = 23;
            this.rented_date.Text = "rented_date";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txt_tot_max_km);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.btn_calculate_km);
            this.groupBox4.Controls.Add(this.txt_extra_km_charge);
            this.groupBox4.Controls.Add(this.extra_km_charge);
            this.groupBox4.Controls.Add(this.txt_extra_km);
            this.groupBox4.Controls.Add(this.extra_km);
            this.groupBox4.Controls.Add(this.txt_number_of_km);
            this.groupBox4.Controls.Add(this.txt_end_km_reading);
            this.groupBox4.Controls.Add(this.txt_start_km_reading);
            this.groupBox4.Controls.Add(this.number_of_km);
            this.groupBox4.Controls.Add(this.end_km_reading);
            this.groupBox4.Controls.Add(this.start_km_reading);
            this.groupBox4.Location = new System.Drawing.Point(470, 356);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(435, 235);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "meter_reading";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // txt_tot_max_km
            // 
            this.txt_tot_max_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tot_max_km.Location = new System.Drawing.Point(246, 98);
            this.txt_tot_max_km.Name = "txt_tot_max_km";
            this.txt_tot_max_km.Size = new System.Drawing.Size(147, 20);
            this.txt_tot_max_km.TabIndex = 51;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(22, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 20);
            this.label2.TabIndex = 50;
            this.label2.Text = "total_maximum_km";
            // 
            // btn_calculate_km
            // 
            this.btn_calculate_km.BackColor = System.Drawing.Color.Olive;
            this.btn_calculate_km.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate_km.Location = new System.Drawing.Point(30, 191);
            this.btn_calculate_km.Name = "btn_calculate_km";
            this.btn_calculate_km.Size = new System.Drawing.Size(158, 37);
            this.btn_calculate_km.TabIndex = 49;
            this.btn_calculate_km.Text = "calculate_km";
            this.btn_calculate_km.UseVisualStyleBackColor = false;
            this.btn_calculate_km.Click += new System.EventHandler(this.btn_calculate_km_Click);
            // 
            // txt_extra_km_charge
            // 
            this.txt_extra_km_charge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km_charge.Location = new System.Drawing.Point(247, 158);
            this.txt_extra_km_charge.Name = "txt_extra_km_charge";
            this.txt_extra_km_charge.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_km_charge.TabIndex = 48;
            // 
            // extra_km_charge
            // 
            this.extra_km_charge.AutoSize = true;
            this.extra_km_charge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_km_charge.Location = new System.Drawing.Point(26, 156);
            this.extra_km_charge.Name = "extra_km_charge";
            this.extra_km_charge.Size = new System.Drawing.Size(147, 20);
            this.extra_km_charge.TabIndex = 47;
            this.extra_km_charge.Text = "extra_km_charge";
            // 
            // txt_extra_km
            // 
            this.txt_extra_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km.Location = new System.Drawing.Point(247, 128);
            this.txt_extra_km.Name = "txt_extra_km";
            this.txt_extra_km.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_km.TabIndex = 46;
            // 
            // extra_km
            // 
            this.extra_km.AutoSize = true;
            this.extra_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_km.Location = new System.Drawing.Point(24, 125);
            this.extra_km.Name = "extra_km";
            this.extra_km.Size = new System.Drawing.Size(82, 20);
            this.extra_km.TabIndex = 45;
            this.extra_km.Text = "extra_km";
            // 
            // txt_number_of_km
            // 
            this.txt_number_of_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_number_of_km.Location = new System.Drawing.Point(247, 68);
            this.txt_number_of_km.Name = "txt_number_of_km";
            this.txt_number_of_km.Size = new System.Drawing.Size(147, 20);
            this.txt_number_of_km.TabIndex = 42;
            // 
            // txt_end_km_reading
            // 
            this.txt_end_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_end_km_reading.Location = new System.Drawing.Point(247, 42);
            this.txt_end_km_reading.Name = "txt_end_km_reading";
            this.txt_end_km_reading.Size = new System.Drawing.Size(147, 20);
            this.txt_end_km_reading.TabIndex = 43;
            // 
            // txt_start_km_reading
            // 
            this.txt_start_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_start_km_reading.Location = new System.Drawing.Point(247, 18);
            this.txt_start_km_reading.Name = "txt_start_km_reading";
            this.txt_start_km_reading.Size = new System.Drawing.Size(147, 20);
            this.txt_start_km_reading.TabIndex = 44;
            // 
            // number_of_km
            // 
            this.number_of_km.AutoSize = true;
            this.number_of_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.number_of_km.Location = new System.Drawing.Point(22, 69);
            this.number_of_km.Name = "number_of_km";
            this.number_of_km.Size = new System.Drawing.Size(128, 20);
            this.number_of_km.TabIndex = 39;
            this.number_of_km.Text = "number_of_km";
            // 
            // end_km_reading
            // 
            this.end_km_reading.AutoSize = true;
            this.end_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.end_km_reading.Location = new System.Drawing.Point(22, 40);
            this.end_km_reading.Name = "end_km_reading";
            this.end_km_reading.Size = new System.Drawing.Size(142, 20);
            this.end_km_reading.TabIndex = 40;
            this.end_km_reading.Text = "end_km_reading";
            // 
            // start_km_reading
            // 
            this.start_km_reading.AutoSize = true;
            this.start_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.start_km_reading.Location = new System.Drawing.Point(22, 16);
            this.start_km_reading.Name = "start_km_reading";
            this.start_km_reading.Size = new System.Drawing.Size(149, 20);
            this.start_km_reading.TabIndex = 41;
            this.start_km_reading.Text = "start_km_reading";
            // 
            // drive_time
            // 
            this.drive_time.AutoSize = true;
            this.drive_time.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.drive_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drive_time.Location = new System.Drawing.Point(378, 9);
            this.drive_time.Name = "drive_time";
            this.drive_time.Size = new System.Drawing.Size(172, 42);
            this.drive_time.TabIndex = 25;
            this.drive_time.Text = "long tour";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 603);
            this.Controls.Add(this.drive_time);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.days);
            this.Controls.Add(this.total_calculate);
            this.Controls.Add(this.package_details);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.package_details.ResumeLayout(false);
            this.package_details.PerformLayout();
            this.total_calculate.ResumeLayout(false);
            this.total_calculate.PerformLayout();
            this.days.ResumeLayout(false);
            this.days.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox package_details;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox total_calculate;
        private System.Windows.Forms.GroupBox days;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txt_vehicle_night_rate;
        private System.Windows.Forms.TextBox txt_maximum_km;
        private System.Windows.Forms.TextBox txt_driver_night_rate;
        private System.Windows.Forms.TextBox txt_vehicle_type;
        private System.Windows.Forms.TextBox txt_package_rate;
        private System.Windows.Forms.TextBox txt_extra_km_rate;
        private System.Windows.Forms.TextBox txt_package_type;
        private System.Windows.Forms.TextBox txt_package_id;
        private System.Windows.Forms.Label vehicle_night_rate;
        private System.Windows.Forms.Label maximum_km;
        private System.Windows.Forms.Label driver_night_rate;
        private System.Windows.Forms.Label vehicle_type;
        private System.Windows.Forms.Label extra_km_rate;
        private System.Windows.Forms.Label package_rate;
        private System.Windows.Forms.Label package_type;
        private System.Windows.Forms.Label package_id;
        private System.Windows.Forms.DateTimePicker returned_date_time_picker;
        private System.Windows.Forms.DateTimePicker rented_date_time_picker;
        private System.Windows.Forms.Label return_date;
        private System.Windows.Forms.Label rented_date;
        private System.Windows.Forms.Label Total_days;
        private System.Windows.Forms.TextBox txt_total_days;
        private System.Windows.Forms.Button btn_calculate_days;
        private System.Windows.Forms.Button btn_calculate_long_hire;
        private System.Windows.Forms.TextBox txt_total_cost;
        private System.Windows.Forms.TextBox txt_total_package_rate;
        private System.Windows.Forms.Label total_cost;
        private System.Windows.Forms.Label total_package_rate;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_calculate_km;
        private System.Windows.Forms.TextBox txt_extra_km_charge;
        private System.Windows.Forms.Label extra_km_charge;
        private System.Windows.Forms.TextBox txt_extra_km;
        private System.Windows.Forms.Label extra_km;
        private System.Windows.Forms.TextBox txt_number_of_km;
        private System.Windows.Forms.TextBox txt_end_km_reading;
        private System.Windows.Forms.TextBox txt_start_km_reading;
        private System.Windows.Forms.Label number_of_km;
        private System.Windows.Forms.Label end_km_reading;
        private System.Windows.Forms.Label start_km_reading;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Label drive_time;
        private System.Windows.Forms.TextBox txt_tot_max_km;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_extra_km_charge_2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_tot_driver_night_rate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_toto_v_night_ratee;
        private System.Windows.Forms.Label label1;
    }
}