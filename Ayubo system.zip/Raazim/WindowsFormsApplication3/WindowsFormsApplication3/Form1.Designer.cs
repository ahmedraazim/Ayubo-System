﻿namespace WindowsFormsApplication3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.vehicle_details = new System.Windows.Forms.Label();
            this.vehicle_num = new System.Windows.Forms.Label();
            this.vehicle_type = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rate_per_day = new System.Windows.Forms.Label();
            this.rate_per_week = new System.Windows.Forms.Label();
            this.driver_rate = new System.Windows.Forms.Label();
            this.txt_Vehicle_Number = new System.Windows.Forms.TextBox();
            this.txt_vehicle_types = new System.Windows.Forms.TextBox();
            this.txt_vehicle_models = new System.Windows.Forms.TextBox();
            this.txt_rate_per_day = new System.Windows.Forms.TextBox();
            this.txt_rate_per_week = new System.Windows.Forms.TextBox();
            this.txt_driver_rate = new System.Windows.Forms.TextBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            this.txt_Rate_Per_Month = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // vehicle_details
            // 
            this.vehicle_details.AutoSize = true;
            this.vehicle_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_details.Location = new System.Drawing.Point(280, 9);
            this.vehicle_details.Name = "vehicle_details";
            this.vehicle_details.Size = new System.Drawing.Size(200, 31);
            this.vehicle_details.TabIndex = 1;
            this.vehicle_details.Text = "vehicle details";
            this.vehicle_details.Click += new System.EventHandler(this.label1_Click);
            // 
            // vehicle_num
            // 
            this.vehicle_num.AutoSize = true;
            this.vehicle_num.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_num.Location = new System.Drawing.Point(110, 105);
            this.vehicle_num.Name = "vehicle_num";
            this.vehicle_num.Size = new System.Drawing.Size(144, 25);
            this.vehicle_num.TabIndex = 1;
            this.vehicle_num.Text = "vehicle_num";
            // 
            // vehicle_type
            // 
            this.vehicle_type.AutoSize = true;
            this.vehicle_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_type.Location = new System.Drawing.Point(110, 139);
            this.vehicle_type.Name = "vehicle_type";
            this.vehicle_type.Size = new System.Drawing.Size(145, 25);
            this.vehicle_type.TabIndex = 1;
            this.vehicle_type.Text = "vehicle_type";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(110, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 25);
            this.label4.TabIndex = 1;
            this.label4.Text = "vehicle_models";
            // 
            // rate_per_day
            // 
            this.rate_per_day.AutoSize = true;
            this.rate_per_day.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rate_per_day.Location = new System.Drawing.Point(110, 213);
            this.rate_per_day.Name = "rate_per_day";
            this.rate_per_day.Size = new System.Drawing.Size(151, 25);
            this.rate_per_day.TabIndex = 1;
            this.rate_per_day.Text = "rate_per_day";
            // 
            // rate_per_week
            // 
            this.rate_per_week.AutoSize = true;
            this.rate_per_week.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rate_per_week.Location = new System.Drawing.Point(110, 249);
            this.rate_per_week.Name = "rate_per_week";
            this.rate_per_week.Size = new System.Drawing.Size(167, 25);
            this.rate_per_week.TabIndex = 1;
            this.rate_per_week.Text = "rate_per_week";
            // 
            // driver_rate
            // 
            this.driver_rate.AutoSize = true;
            this.driver_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driver_rate.Location = new System.Drawing.Point(110, 289);
            this.driver_rate.Name = "driver_rate";
            this.driver_rate.Size = new System.Drawing.Size(126, 25);
            this.driver_rate.TabIndex = 1;
            this.driver_rate.Text = "driver_rate";
            // 
            // txt_Vehicle_Number
            // 
            this.txt_Vehicle_Number.Location = new System.Drawing.Point(448, 105);
            this.txt_Vehicle_Number.Name = "txt_Vehicle_Number";
            this.txt_Vehicle_Number.Size = new System.Drawing.Size(147, 20);
            this.txt_Vehicle_Number.TabIndex = 2;
            // 
            // txt_vehicle_types
            // 
            this.txt_vehicle_types.Location = new System.Drawing.Point(448, 145);
            this.txt_vehicle_types.Name = "txt_vehicle_types";
            this.txt_vehicle_types.Size = new System.Drawing.Size(147, 20);
            this.txt_vehicle_types.TabIndex = 2;
            // 
            // txt_vehicle_models
            // 
            this.txt_vehicle_models.Location = new System.Drawing.Point(448, 180);
            this.txt_vehicle_models.Name = "txt_vehicle_models";
            this.txt_vehicle_models.Size = new System.Drawing.Size(147, 20);
            this.txt_vehicle_models.TabIndex = 2;
            // 
            // txt_rate_per_day
            // 
            this.txt_rate_per_day.Location = new System.Drawing.Point(448, 219);
            this.txt_rate_per_day.Name = "txt_rate_per_day";
            this.txt_rate_per_day.Size = new System.Drawing.Size(147, 20);
            this.txt_rate_per_day.TabIndex = 2;
            // 
            // txt_rate_per_week
            // 
            this.txt_rate_per_week.Location = new System.Drawing.Point(448, 255);
            this.txt_rate_per_week.Name = "txt_rate_per_week";
            this.txt_rate_per_week.Size = new System.Drawing.Size(147, 20);
            this.txt_rate_per_week.TabIndex = 2;
            // 
            // txt_driver_rate
            // 
            this.txt_driver_rate.Location = new System.Drawing.Point(448, 295);
            this.txt_driver_rate.Name = "txt_driver_rate";
            this.txt_driver_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_driver_rate.TabIndex = 2;
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.Teal;
            this.btn_delete.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(452, 372);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(99, 37);
            this.btn_delete.TabIndex = 6;
            this.btn_delete.Text = "delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Teal;
            this.btn_update.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(309, 372);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(99, 37);
            this.btn_update.TabIndex = 7;
            this.btn_update.Text = "update";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Teal;
            this.btn_close.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.Location = new System.Drawing.Point(603, 372);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(99, 37);
            this.btn_close.TabIndex = 8;
            this.btn_close.Text = "close";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Teal;
            this.btn_search.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(22, 372);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(99, 37);
            this.btn_search.TabIndex = 9;
            this.btn_search.Text = "search";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.BackColor = System.Drawing.Color.Teal;
            this.btn_insert.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insert.Location = new System.Drawing.Point(158, 372);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(99, 37);
            this.btn_insert.TabIndex = 10;
            this.btn_insert.Text = "insert";
            this.btn_insert.UseVisualStyleBackColor = false;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // txt_Rate_Per_Month
            // 
            this.txt_Rate_Per_Month.Location = new System.Drawing.Point(448, 330);
            this.txt_Rate_Per_Month.Name = "txt_Rate_Per_Month";
            this.txt_Rate_Per_Month.Size = new System.Drawing.Size(147, 20);
            this.txt_Rate_Per_Month.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(110, 324);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(177, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "rate_per_month";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 479);
            this.Controls.Add(this.txt_Rate_Per_Month);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_insert);
            this.Controls.Add(this.txt_driver_rate);
            this.Controls.Add(this.txt_rate_per_week);
            this.Controls.Add(this.txt_rate_per_day);
            this.Controls.Add(this.txt_vehicle_models);
            this.Controls.Add(this.txt_vehicle_types);
            this.Controls.Add(this.txt_Vehicle_Number);
            this.Controls.Add(this.driver_rate);
            this.Controls.Add(this.rate_per_week);
            this.Controls.Add(this.rate_per_day);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.vehicle_type);
            this.Controls.Add(this.vehicle_num);
            this.Controls.Add(this.vehicle_details);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label vehicle_details;
        private System.Windows.Forms.Label vehicle_num;
        private System.Windows.Forms.Label vehicle_type;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label rate_per_day;
        private System.Windows.Forms.Label rate_per_week;
        private System.Windows.Forms.Label driver_rate;
        private System.Windows.Forms.TextBox txt_Vehicle_Number;
        private System.Windows.Forms.TextBox txt_vehicle_types;
        private System.Windows.Forms.TextBox txt_vehicle_models;
        private System.Windows.Forms.TextBox txt_rate_per_day;
        private System.Windows.Forms.TextBox txt_rate_per_week;
        private System.Windows.Forms.TextBox txt_driver_rate;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.TextBox txt_Rate_Per_Month;
        private System.Windows.Forms.Label label1;
    }
}

