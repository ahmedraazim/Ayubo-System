﻿namespace WindowsFormsApplication3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_search = new System.Windows.Forms.Button();
            this.btn_insert = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.package_id = new System.Windows.Forms.Label();
            this.package_type = new System.Windows.Forms.Label();
            this.package_rate = new System.Windows.Forms.Label();
            this.vehicle_type = new System.Windows.Forms.Label();
            this.maximum_km = new System.Windows.Forms.Label();
            this.maximum_hours = new System.Windows.Forms.Label();
            this.extra_km_rate = new System.Windows.Forms.Label();
            this.extra_hours_rate = new System.Windows.Forms.Label();
            this.driver_night_rate = new System.Windows.Forms.Label();
            this.vehicle_night_rate = new System.Windows.Forms.Label();
            this.details = new System.Windows.Forms.Label();
            this.txt_maximum_hours = new System.Windows.Forms.TextBox();
            this.txt_maximum_km = new System.Windows.Forms.TextBox();
            this.txt_vehicle_type = new System.Windows.Forms.TextBox();
            this.txt_package_rate = new System.Windows.Forms.TextBox();
            this.txt_package_type = new System.Windows.Forms.TextBox();
            this.txt_package_id = new System.Windows.Forms.TextBox();
            this.txt_extra_km_rate = new System.Windows.Forms.TextBox();
            this.txt_extra_hours_rate = new System.Windows.Forms.TextBox();
            this.txt_driver_night_rate = new System.Windows.Forms.TextBox();
            this.txt_vehicle_night_rate = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.Teal;
            this.btn_delete.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(673, 517);
            this.btn_delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(132, 46);
            this.btn_delete.TabIndex = 1;
            this.btn_delete.Text = "delete";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_update
            // 
            this.btn_update.BackColor = System.Drawing.Color.Teal;
            this.btn_update.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(483, 517);
            this.btn_update.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(132, 46);
            this.btn_update.TabIndex = 2;
            this.btn_update.Text = "update";
            this.btn_update.UseVisualStyleBackColor = false;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Teal;
            this.btn_close.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.Location = new System.Drawing.Point(875, 517);
            this.btn_close.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(132, 46);
            this.btn_close.TabIndex = 3;
            this.btn_close.Text = "close";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Teal;
            this.btn_search.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(100, 517);
            this.btn_search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(132, 46);
            this.btn_search.TabIndex = 4;
            this.btn_search.Text = "search";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // btn_insert
            // 
            this.btn_insert.BackColor = System.Drawing.Color.Teal;
            this.btn_insert.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_insert.Location = new System.Drawing.Point(281, 517);
            this.btn_insert.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_insert.Name = "btn_insert";
            this.btn_insert.Size = new System.Drawing.Size(132, 46);
            this.btn_insert.TabIndex = 5;
            this.btn_insert.Text = "insert";
            this.btn_insert.UseVisualStyleBackColor = false;
            this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(473, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 46);
            this.label1.TabIndex = 6;
            this.label1.Text = "package";
            // 
            // package_id
            // 
            this.package_id.AutoSize = true;
            this.package_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_id.Location = new System.Drawing.Point(181, 150);
            this.package_id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.package_id.Name = "package_id";
            this.package_id.Size = new System.Drawing.Size(123, 25);
            this.package_id.TabIndex = 6;
            this.package_id.Text = "package_id";
            // 
            // package_type
            // 
            this.package_type.AutoSize = true;
            this.package_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_type.Location = new System.Drawing.Point(181, 180);
            this.package_type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.package_type.Name = "package_type";
            this.package_type.Size = new System.Drawing.Size(147, 25);
            this.package_type.TabIndex = 6;
            this.package_type.Text = "package_type";
            // 
            // package_rate
            // 
            this.package_rate.AutoSize = true;
            this.package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_rate.Location = new System.Drawing.Point(181, 210);
            this.package_rate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.package_rate.Name = "package_rate";
            this.package_rate.Size = new System.Drawing.Size(143, 25);
            this.package_rate.TabIndex = 6;
            this.package_rate.Text = "package_rate";
            // 
            // vehicle_type
            // 
            this.vehicle_type.AutoSize = true;
            this.vehicle_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_type.Location = new System.Drawing.Point(181, 245);
            this.vehicle_type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.vehicle_type.Name = "vehicle_type";
            this.vehicle_type.Size = new System.Drawing.Size(133, 25);
            this.vehicle_type.TabIndex = 6;
            this.vehicle_type.Text = "vehicle_type";
            // 
            // maximum_km
            // 
            this.maximum_km.AutoSize = true;
            this.maximum_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maximum_km.Location = new System.Drawing.Point(181, 276);
            this.maximum_km.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.maximum_km.Name = "maximum_km";
            this.maximum_km.Size = new System.Drawing.Size(143, 25);
            this.maximum_km.TabIndex = 6;
            this.maximum_km.Text = "maximum_km";
            // 
            // maximum_hours
            // 
            this.maximum_hours.AutoSize = true;
            this.maximum_hours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maximum_hours.Location = new System.Drawing.Point(181, 304);
            this.maximum_hours.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.maximum_hours.Name = "maximum_hours";
            this.maximum_hours.Size = new System.Drawing.Size(169, 25);
            this.maximum_hours.TabIndex = 6;
            this.maximum_hours.Text = "maximum_hours";
            // 
            // extra_km_rate
            // 
            this.extra_km_rate.AutoSize = true;
            this.extra_km_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_km_rate.Location = new System.Drawing.Point(181, 334);
            this.extra_km_rate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.extra_km_rate.Name = "extra_km_rate";
            this.extra_km_rate.Size = new System.Drawing.Size(149, 25);
            this.extra_km_rate.TabIndex = 6;
            this.extra_km_rate.Text = "extra_km_rate";
            // 
            // extra_hours_rate
            // 
            this.extra_hours_rate.AutoSize = true;
            this.extra_hours_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_hours_rate.Location = new System.Drawing.Point(181, 364);
            this.extra_hours_rate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.extra_hours_rate.Name = "extra_hours_rate";
            this.extra_hours_rate.Size = new System.Drawing.Size(175, 25);
            this.extra_hours_rate.TabIndex = 6;
            this.extra_hours_rate.Text = "extra_hours_rate";
            // 
            // driver_night_rate
            // 
            this.driver_night_rate.AutoSize = true;
            this.driver_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driver_night_rate.Location = new System.Drawing.Point(181, 399);
            this.driver_night_rate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.driver_night_rate.Name = "driver_night_rate";
            this.driver_night_rate.Size = new System.Drawing.Size(174, 25);
            this.driver_night_rate.TabIndex = 6;
            this.driver_night_rate.Text = "driver_night_rate";
            // 
            // vehicle_night_rate
            // 
            this.vehicle_night_rate.AutoSize = true;
            this.vehicle_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_night_rate.Location = new System.Drawing.Point(181, 430);
            this.vehicle_night_rate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.vehicle_night_rate.Name = "vehicle_night_rate";
            this.vehicle_night_rate.Size = new System.Drawing.Size(188, 25);
            this.vehicle_night_rate.TabIndex = 6;
            this.vehicle_night_rate.Text = "vehicle_night_rate";
            // 
            // details
            // 
            this.details.AutoSize = true;
            this.details.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.details.Location = new System.Drawing.Point(197, 79);
            this.details.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.details.Name = "details";
            this.details.Size = new System.Drawing.Size(123, 39);
            this.details.TabIndex = 6;
            this.details.Text = "details";
            // 
            // txt_maximum_hours
            // 
            this.txt_maximum_hours.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maximum_hours.Location = new System.Drawing.Point(559, 304);
            this.txt_maximum_hours.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_maximum_hours.Name = "txt_maximum_hours";
            this.txt_maximum_hours.Size = new System.Drawing.Size(195, 23);
            this.txt_maximum_hours.TabIndex = 7;
            // 
            // txt_maximum_km
            // 
            this.txt_maximum_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maximum_km.Location = new System.Drawing.Point(559, 276);
            this.txt_maximum_km.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_maximum_km.Name = "txt_maximum_km";
            this.txt_maximum_km.Size = new System.Drawing.Size(195, 23);
            this.txt_maximum_km.TabIndex = 8;
            // 
            // txt_vehicle_type
            // 
            this.txt_vehicle_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_vehicle_type.Location = new System.Drawing.Point(559, 245);
            this.txt_vehicle_type.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_vehicle_type.Name = "txt_vehicle_type";
            this.txt_vehicle_type.Size = new System.Drawing.Size(195, 23);
            this.txt_vehicle_type.TabIndex = 9;
            // 
            // txt_package_rate
            // 
            this.txt_package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_rate.Location = new System.Drawing.Point(559, 210);
            this.txt_package_rate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_package_rate.Name = "txt_package_rate";
            this.txt_package_rate.Size = new System.Drawing.Size(195, 23);
            this.txt_package_rate.TabIndex = 10;
            // 
            // txt_package_type
            // 
            this.txt_package_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_type.Location = new System.Drawing.Point(559, 180);
            this.txt_package_type.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_package_type.Name = "txt_package_type";
            this.txt_package_type.Size = new System.Drawing.Size(195, 23);
            this.txt_package_type.TabIndex = 11;
            // 
            // txt_package_id
            // 
            this.txt_package_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_id.Location = new System.Drawing.Point(559, 150);
            this.txt_package_id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_package_id.Name = "txt_package_id";
            this.txt_package_id.Size = new System.Drawing.Size(195, 23);
            this.txt_package_id.TabIndex = 12;
            // 
            // txt_extra_km_rate
            // 
            this.txt_extra_km_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km_rate.Location = new System.Drawing.Point(559, 331);
            this.txt_extra_km_rate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_extra_km_rate.Name = "txt_extra_km_rate";
            this.txt_extra_km_rate.Size = new System.Drawing.Size(195, 23);
            this.txt_extra_km_rate.TabIndex = 12;
            // 
            // txt_extra_hours_rate
            // 
            this.txt_extra_hours_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_hours_rate.Location = new System.Drawing.Point(559, 361);
            this.txt_extra_hours_rate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_extra_hours_rate.Name = "txt_extra_hours_rate";
            this.txt_extra_hours_rate.Size = new System.Drawing.Size(195, 23);
            this.txt_extra_hours_rate.TabIndex = 11;
            // 
            // txt_driver_night_rate
            // 
            this.txt_driver_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_driver_night_rate.Location = new System.Drawing.Point(559, 391);
            this.txt_driver_night_rate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_driver_night_rate.Name = "txt_driver_night_rate";
            this.txt_driver_night_rate.Size = new System.Drawing.Size(195, 23);
            this.txt_driver_night_rate.TabIndex = 10;
            // 
            // txt_vehicle_night_rate
            // 
            this.txt_vehicle_night_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_vehicle_night_rate.Location = new System.Drawing.Point(559, 426);
            this.txt_vehicle_night_rate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txt_vehicle_night_rate.Name = "txt_vehicle_night_rate";
            this.txt_vehicle_night_rate.Size = new System.Drawing.Size(195, 23);
            this.txt_vehicle_night_rate.TabIndex = 9;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1127, 577);
            this.Controls.Add(this.txt_maximum_hours);
            this.Controls.Add(this.txt_vehicle_night_rate);
            this.Controls.Add(this.txt_maximum_km);
            this.Controls.Add(this.txt_driver_night_rate);
            this.Controls.Add(this.txt_vehicle_type);
            this.Controls.Add(this.txt_extra_hours_rate);
            this.Controls.Add(this.txt_package_rate);
            this.Controls.Add(this.txt_extra_km_rate);
            this.Controls.Add(this.txt_package_type);
            this.Controls.Add(this.txt_package_id);
            this.Controls.Add(this.vehicle_night_rate);
            this.Controls.Add(this.maximum_km);
            this.Controls.Add(this.driver_night_rate);
            this.Controls.Add(this.extra_hours_rate);
            this.Controls.Add(this.vehicle_type);
            this.Controls.Add(this.extra_km_rate);
            this.Controls.Add(this.package_rate);
            this.Controls.Add(this.maximum_hours);
            this.Controls.Add(this.package_type);
            this.Controls.Add(this.package_id);
            this.Controls.Add(this.details);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.btn_insert);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label package_id;
        private System.Windows.Forms.Label package_type;
        private System.Windows.Forms.Label package_rate;
        private System.Windows.Forms.Label vehicle_type;
        private System.Windows.Forms.Label maximum_km;
        private System.Windows.Forms.Label maximum_hours;
        private System.Windows.Forms.Label extra_km_rate;
        private System.Windows.Forms.Label extra_hours_rate;
        private System.Windows.Forms.Label driver_night_rate;
        private System.Windows.Forms.Label vehicle_night_rate;
        private System.Windows.Forms.Label details;
        private System.Windows.Forms.TextBox txt_maximum_hours;
        private System.Windows.Forms.TextBox txt_maximum_km;
        private System.Windows.Forms.TextBox txt_vehicle_type;
        private System.Windows.Forms.TextBox txt_package_rate;
        private System.Windows.Forms.TextBox txt_package_type;
        private System.Windows.Forms.TextBox txt_package_id;
        private System.Windows.Forms.TextBox txt_extra_km_rate;
        private System.Windows.Forms.TextBox txt_extra_hours_rate;
        private System.Windows.Forms.TextBox txt_driver_night_rate;
        private System.Windows.Forms.TextBox txt_vehicle_night_rate;
    }
}