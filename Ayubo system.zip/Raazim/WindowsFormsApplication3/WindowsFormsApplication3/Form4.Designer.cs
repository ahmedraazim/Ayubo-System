﻿namespace WindowsFormsApplication3
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.package_details = new System.Windows.Forms.GroupBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_maximum_hours = new System.Windows.Forms.TextBox();
            this.txt_extra_hours_rate = new System.Windows.Forms.TextBox();
            this.txt_extra_km_rate = new System.Windows.Forms.TextBox();
            this.extra_hours_rate = new System.Windows.Forms.Label();
            this.extra_km_rate = new System.Windows.Forms.Label();
            this.maximum_hours = new System.Windows.Forms.Label();
            this.txt_maximum_km = new System.Windows.Forms.TextBox();
            this.maximum_km = new System.Windows.Forms.Label();
            this.txt_package_rate = new System.Windows.Forms.TextBox();
            this.txt_package_type = new System.Windows.Forms.TextBox();
            this.txt_package_id = new System.Windows.Forms.TextBox();
            this.package_rate = new System.Windows.Forms.Label();
            this.package_type = new System.Windows.Forms.Label();
            this.package_id = new System.Windows.Forms.Label();
            this.btn_calculate_hours = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.extra_hours_charge = new System.Windows.Forms.Label();
            this.extra_hours = new System.Windows.Forms.Label();
            this.number_of_hours = new System.Windows.Forms.Label();
            this.end_time = new System.Windows.Forms.Label();
            this.star_time = new System.Windows.Forms.Label();
            this.txt_extra_hours_charge = new System.Windows.Forms.TextBox();
            this.txt_extra_hours = new System.Windows.Forms.TextBox();
            this.txt_number_of_hours = new System.Windows.Forms.TextBox();
            this.end_time_date_time_picker = new System.Windows.Forms.DateTimePicker();
            this.start_time_date_time_picker = new System.Windows.Forms.DateTimePicker();
            this.meter_reading = new System.Windows.Forms.GroupBox();
            this.btn_calculate_km = new System.Windows.Forms.Button();
            this.txt_extra_km_charge = new System.Windows.Forms.TextBox();
            this.extra_km_charge = new System.Windows.Forms.Label();
            this.txt_extra_km = new System.Windows.Forms.TextBox();
            this.extra_km = new System.Windows.Forms.Label();
            this.txt_number_of_km = new System.Windows.Forms.TextBox();
            this.txt_end_km_reading = new System.Windows.Forms.TextBox();
            this.txt_start_km_reading = new System.Windows.Forms.TextBox();
            this.number_of_km = new System.Windows.Forms.Label();
            this.end_km_reading = new System.Windows.Forms.Label();
            this.start_km_reading = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_calculate_day_hire = new System.Windows.Forms.Button();
            this.Total_cost = new System.Windows.Forms.Label();
            this.txt_total_cost = new System.Windows.Forms.TextBox();
            this.drive_time = new System.Windows.Forms.Label();
            this.package_details.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.meter_reading.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // package_details
            // 
            this.package_details.Controls.Add(this.btn_search);
            this.package_details.Controls.Add(this.txt_maximum_hours);
            this.package_details.Controls.Add(this.txt_extra_hours_rate);
            this.package_details.Controls.Add(this.txt_extra_km_rate);
            this.package_details.Controls.Add(this.extra_hours_rate);
            this.package_details.Controls.Add(this.extra_km_rate);
            this.package_details.Controls.Add(this.maximum_hours);
            this.package_details.Controls.Add(this.txt_maximum_km);
            this.package_details.Controls.Add(this.maximum_km);
            this.package_details.Controls.Add(this.txt_package_rate);
            this.package_details.Controls.Add(this.txt_package_type);
            this.package_details.Controls.Add(this.txt_package_id);
            this.package_details.Controls.Add(this.package_rate);
            this.package_details.Controls.Add(this.package_type);
            this.package_details.Controls.Add(this.package_id);
            this.package_details.Location = new System.Drawing.Point(28, 61);
            this.package_details.Name = "package_details";
            this.package_details.Size = new System.Drawing.Size(428, 275);
            this.package_details.TabIndex = 8;
            this.package_details.TabStop = false;
            this.package_details.Text = "package_details";
            this.package_details.Enter += new System.EventHandler(this.package_details_Enter);
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Teal;
            this.btn_search.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(155, 232);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(158, 37);
            this.btn_search.TabIndex = 28;
            this.btn_search.Text = "search";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txt_maximum_hours
            // 
            this.txt_maximum_hours.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maximum_hours.Location = new System.Drawing.Point(259, 132);
            this.txt_maximum_hours.Name = "txt_maximum_hours";
            this.txt_maximum_hours.Size = new System.Drawing.Size(147, 20);
            this.txt_maximum_hours.TabIndex = 24;
            // 
            // txt_extra_hours_rate
            // 
            this.txt_extra_hours_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_hours_rate.Location = new System.Drawing.Point(259, 184);
            this.txt_extra_hours_rate.Name = "txt_extra_hours_rate";
            this.txt_extra_hours_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_hours_rate.TabIndex = 25;
            // 
            // txt_extra_km_rate
            // 
            this.txt_extra_km_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km_rate.Location = new System.Drawing.Point(259, 158);
            this.txt_extra_km_rate.Name = "txt_extra_km_rate";
            this.txt_extra_km_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_km_rate.TabIndex = 26;
            // 
            // extra_hours_rate
            // 
            this.extra_hours_rate.AutoSize = true;
            this.extra_hours_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_hours_rate.Location = new System.Drawing.Point(36, 184);
            this.extra_hours_rate.Name = "extra_hours_rate";
            this.extra_hours_rate.Size = new System.Drawing.Size(146, 20);
            this.extra_hours_rate.TabIndex = 21;
            this.extra_hours_rate.Text = "extra_hours_rate";
            // 
            // extra_km_rate
            // 
            this.extra_km_rate.AutoSize = true;
            this.extra_km_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_km_rate.Location = new System.Drawing.Point(36, 158);
            this.extra_km_rate.Name = "extra_km_rate";
            this.extra_km_rate.Size = new System.Drawing.Size(124, 20);
            this.extra_km_rate.TabIndex = 22;
            this.extra_km_rate.Text = "extra_km_rate";
            // 
            // maximum_hours
            // 
            this.maximum_hours.AutoSize = true;
            this.maximum_hours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maximum_hours.Location = new System.Drawing.Point(36, 132);
            this.maximum_hours.Name = "maximum_hours";
            this.maximum_hours.Size = new System.Drawing.Size(138, 20);
            this.maximum_hours.TabIndex = 23;
            this.maximum_hours.Text = "maximum_hours";
            // 
            // txt_maximum_km
            // 
            this.txt_maximum_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_maximum_km.Location = new System.Drawing.Point(259, 106);
            this.txt_maximum_km.Name = "txt_maximum_km";
            this.txt_maximum_km.Size = new System.Drawing.Size(147, 20);
            this.txt_maximum_km.TabIndex = 20;
            // 
            // maximum_km
            // 
            this.maximum_km.AutoSize = true;
            this.maximum_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.maximum_km.Location = new System.Drawing.Point(34, 108);
            this.maximum_km.Name = "maximum_km";
            this.maximum_km.Size = new System.Drawing.Size(116, 20);
            this.maximum_km.TabIndex = 19;
            this.maximum_km.Text = "maximum_km";
            // 
            // txt_package_rate
            // 
            this.txt_package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_rate.Location = new System.Drawing.Point(259, 80);
            this.txt_package_rate.Name = "txt_package_rate";
            this.txt_package_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_package_rate.TabIndex = 16;
            // 
            // txt_package_type
            // 
            this.txt_package_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_type.Location = new System.Drawing.Point(259, 54);
            this.txt_package_type.Name = "txt_package_type";
            this.txt_package_type.Size = new System.Drawing.Size(147, 20);
            this.txt_package_type.TabIndex = 17;
            // 
            // txt_package_id
            // 
            this.txt_package_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_package_id.Location = new System.Drawing.Point(259, 30);
            this.txt_package_id.Name = "txt_package_id";
            this.txt_package_id.Size = new System.Drawing.Size(147, 20);
            this.txt_package_id.TabIndex = 18;
            // 
            // package_rate
            // 
            this.package_rate.AutoSize = true;
            this.package_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_rate.Location = new System.Drawing.Point(34, 81);
            this.package_rate.Name = "package_rate";
            this.package_rate.Size = new System.Drawing.Size(119, 20);
            this.package_rate.TabIndex = 13;
            this.package_rate.Text = "package_rate";
            // 
            // package_type
            // 
            this.package_type.AutoSize = true;
            this.package_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_type.Location = new System.Drawing.Point(34, 52);
            this.package_type.Name = "package_type";
            this.package_type.Size = new System.Drawing.Size(121, 20);
            this.package_type.TabIndex = 14;
            this.package_type.Text = "package_type";
            // 
            // package_id
            // 
            this.package_id.AutoSize = true;
            this.package_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.package_id.Location = new System.Drawing.Point(34, 28);
            this.package_id.Name = "package_id";
            this.package_id.Size = new System.Drawing.Size(101, 20);
            this.package_id.TabIndex = 15;
            this.package_id.Text = "package_id";
            // 
            // btn_calculate_hours
            // 
            this.btn_calculate_hours.BackColor = System.Drawing.Color.Olive;
            this.btn_calculate_hours.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate_hours.Location = new System.Drawing.Point(155, 212);
            this.btn_calculate_hours.Name = "btn_calculate_hours";
            this.btn_calculate_hours.Size = new System.Drawing.Size(158, 37);
            this.btn_calculate_hours.TabIndex = 27;
            this.btn_calculate_hours.Text = "calculate_hours";
            this.btn_calculate_hours.UseVisualStyleBackColor = false;
            this.btn_calculate_hours.Click += new System.EventHandler(this.btn_calculate_hours_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_calculate_hours);
            this.groupBox1.Controls.Add(this.extra_hours_charge);
            this.groupBox1.Controls.Add(this.extra_hours);
            this.groupBox1.Controls.Add(this.number_of_hours);
            this.groupBox1.Controls.Add(this.end_time);
            this.groupBox1.Controls.Add(this.star_time);
            this.groupBox1.Controls.Add(this.txt_extra_hours_charge);
            this.groupBox1.Controls.Add(this.txt_extra_hours);
            this.groupBox1.Controls.Add(this.txt_number_of_hours);
            this.groupBox1.Controls.Add(this.end_time_date_time_picker);
            this.groupBox1.Controls.Add(this.start_time_date_time_picker);
            this.groupBox1.Location = new System.Drawing.Point(28, 342);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(428, 249);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "time";
            // 
            // extra_hours_charge
            // 
            this.extra_hours_charge.AutoSize = true;
            this.extra_hours_charge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_hours_charge.Location = new System.Drawing.Point(35, 178);
            this.extra_hours_charge.Name = "extra_hours_charge";
            this.extra_hours_charge.Size = new System.Drawing.Size(169, 20);
            this.extra_hours_charge.TabIndex = 2;
            this.extra_hours_charge.Text = "extra_hours_charge";
            // 
            // extra_hours
            // 
            this.extra_hours.AutoSize = true;
            this.extra_hours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_hours.Location = new System.Drawing.Point(35, 140);
            this.extra_hours.Name = "extra_hours";
            this.extra_hours.Size = new System.Drawing.Size(104, 20);
            this.extra_hours.TabIndex = 2;
            this.extra_hours.Text = "extra_hours";
            // 
            // number_of_hours
            // 
            this.number_of_hours.AutoSize = true;
            this.number_of_hours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.number_of_hours.Location = new System.Drawing.Point(35, 100);
            this.number_of_hours.Name = "number_of_hours";
            this.number_of_hours.Size = new System.Drawing.Size(150, 20);
            this.number_of_hours.TabIndex = 2;
            this.number_of_hours.Text = "number_of_hours";
            // 
            // end_time
            // 
            this.end_time.AutoSize = true;
            this.end_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.end_time.Location = new System.Drawing.Point(35, 61);
            this.end_time.Name = "end_time";
            this.end_time.Size = new System.Drawing.Size(83, 20);
            this.end_time.TabIndex = 2;
            this.end_time.Text = "end_time";
            // 
            // star_time
            // 
            this.star_time.AutoSize = true;
            this.star_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.star_time.Location = new System.Drawing.Point(35, 25);
            this.star_time.Name = "star_time";
            this.star_time.Size = new System.Drawing.Size(84, 20);
            this.star_time.TabIndex = 2;
            this.star_time.Text = "star_time";
            // 
            // txt_extra_hours_charge
            // 
            this.txt_extra_hours_charge.Location = new System.Drawing.Point(259, 180);
            this.txt_extra_hours_charge.Name = "txt_extra_hours_charge";
            this.txt_extra_hours_charge.Size = new System.Drawing.Size(127, 20);
            this.txt_extra_hours_charge.TabIndex = 1;
            // 
            // txt_extra_hours
            // 
            this.txt_extra_hours.Location = new System.Drawing.Point(259, 142);
            this.txt_extra_hours.Name = "txt_extra_hours";
            this.txt_extra_hours.Size = new System.Drawing.Size(127, 20);
            this.txt_extra_hours.TabIndex = 1;
            // 
            // txt_number_of_hours
            // 
            this.txt_number_of_hours.Location = new System.Drawing.Point(259, 104);
            this.txt_number_of_hours.Name = "txt_number_of_hours";
            this.txt_number_of_hours.Size = new System.Drawing.Size(127, 20);
            this.txt_number_of_hours.TabIndex = 1;
            // 
            // end_time_date_time_picker
            // 
            this.end_time_date_time_picker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.end_time_date_time_picker.Location = new System.Drawing.Point(193, 54);
            this.end_time_date_time_picker.Name = "end_time_date_time_picker";
            this.end_time_date_time_picker.Size = new System.Drawing.Size(200, 20);
            this.end_time_date_time_picker.TabIndex = 0;
            // 
            // start_time_date_time_picker
            // 
            this.start_time_date_time_picker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.start_time_date_time_picker.Location = new System.Drawing.Point(193, 19);
            this.start_time_date_time_picker.Name = "start_time_date_time_picker";
            this.start_time_date_time_picker.Size = new System.Drawing.Size(200, 20);
            this.start_time_date_time_picker.TabIndex = 0;
            // 
            // meter_reading
            // 
            this.meter_reading.Controls.Add(this.btn_calculate_km);
            this.meter_reading.Controls.Add(this.txt_extra_km_charge);
            this.meter_reading.Controls.Add(this.extra_km_charge);
            this.meter_reading.Controls.Add(this.txt_extra_km);
            this.meter_reading.Controls.Add(this.extra_km);
            this.meter_reading.Controls.Add(this.txt_number_of_km);
            this.meter_reading.Controls.Add(this.txt_end_km_reading);
            this.meter_reading.Controls.Add(this.txt_start_km_reading);
            this.meter_reading.Controls.Add(this.number_of_km);
            this.meter_reading.Controls.Add(this.end_km_reading);
            this.meter_reading.Controls.Add(this.start_km_reading);
            this.meter_reading.Location = new System.Drawing.Point(564, 62);
            this.meter_reading.Name = "meter_reading";
            this.meter_reading.Size = new System.Drawing.Size(400, 274);
            this.meter_reading.TabIndex = 29;
            this.meter_reading.TabStop = false;
            this.meter_reading.Text = "meter_reading";
            // 
            // btn_calculate_km
            // 
            this.btn_calculate_km.BackColor = System.Drawing.Color.Olive;
            this.btn_calculate_km.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate_km.Location = new System.Drawing.Point(140, 202);
            this.btn_calculate_km.Name = "btn_calculate_km";
            this.btn_calculate_km.Size = new System.Drawing.Size(158, 37);
            this.btn_calculate_km.TabIndex = 38;
            this.btn_calculate_km.Text = "calculate_km";
            this.btn_calculate_km.UseVisualStyleBackColor = false;
            this.btn_calculate_km.Click += new System.EventHandler(this.btn_calculate_km_Click);
            // 
            // txt_extra_km_charge
            // 
            this.txt_extra_km_charge.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km_charge.Location = new System.Drawing.Point(251, 133);
            this.txt_extra_km_charge.Name = "txt_extra_km_charge";
            this.txt_extra_km_charge.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_km_charge.TabIndex = 37;
            // 
            // extra_km_charge
            // 
            this.extra_km_charge.AutoSize = true;
            this.extra_km_charge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_km_charge.Location = new System.Drawing.Point(28, 133);
            this.extra_km_charge.Name = "extra_km_charge";
            this.extra_km_charge.Size = new System.Drawing.Size(147, 20);
            this.extra_km_charge.TabIndex = 36;
            this.extra_km_charge.Text = "extra_km_charge";
            // 
            // txt_extra_km
            // 
            this.txt_extra_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_extra_km.Location = new System.Drawing.Point(251, 107);
            this.txt_extra_km.Name = "txt_extra_km";
            this.txt_extra_km.Size = new System.Drawing.Size(147, 20);
            this.txt_extra_km.TabIndex = 34;
            // 
            // extra_km
            // 
            this.extra_km.AutoSize = true;
            this.extra_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_km.Location = new System.Drawing.Point(26, 109);
            this.extra_km.Name = "extra_km";
            this.extra_km.Size = new System.Drawing.Size(82, 20);
            this.extra_km.TabIndex = 33;
            this.extra_km.Text = "extra_km";
            // 
            // txt_number_of_km
            // 
            this.txt_number_of_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_number_of_km.Location = new System.Drawing.Point(251, 81);
            this.txt_number_of_km.Name = "txt_number_of_km";
            this.txt_number_of_km.Size = new System.Drawing.Size(147, 20);
            this.txt_number_of_km.TabIndex = 30;
            // 
            // txt_end_km_reading
            // 
            this.txt_end_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_end_km_reading.Location = new System.Drawing.Point(251, 55);
            this.txt_end_km_reading.Name = "txt_end_km_reading";
            this.txt_end_km_reading.Size = new System.Drawing.Size(147, 20);
            this.txt_end_km_reading.TabIndex = 31;
            // 
            // txt_start_km_reading
            // 
            this.txt_start_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_start_km_reading.Location = new System.Drawing.Point(251, 31);
            this.txt_start_km_reading.Name = "txt_start_km_reading";
            this.txt_start_km_reading.Size = new System.Drawing.Size(147, 20);
            this.txt_start_km_reading.TabIndex = 32;
            // 
            // number_of_km
            // 
            this.number_of_km.AutoSize = true;
            this.number_of_km.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.number_of_km.Location = new System.Drawing.Point(26, 82);
            this.number_of_km.Name = "number_of_km";
            this.number_of_km.Size = new System.Drawing.Size(128, 20);
            this.number_of_km.TabIndex = 27;
            this.number_of_km.Text = "number_of_km";
            // 
            // end_km_reading
            // 
            this.end_km_reading.AutoSize = true;
            this.end_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.end_km_reading.Location = new System.Drawing.Point(26, 53);
            this.end_km_reading.Name = "end_km_reading";
            this.end_km_reading.Size = new System.Drawing.Size(142, 20);
            this.end_km_reading.TabIndex = 28;
            this.end_km_reading.Text = "end_km_reading";
            // 
            // start_km_reading
            // 
            this.start_km_reading.AutoSize = true;
            this.start_km_reading.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.start_km_reading.Location = new System.Drawing.Point(26, 29);
            this.start_km_reading.Name = "start_km_reading";
            this.start_km_reading.Size = new System.Drawing.Size(149, 20);
            this.start_km_reading.TabIndex = 29;
            this.start_km_reading.Text = "start_km_reading";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_close);
            this.groupBox2.Controls.Add(this.btn_calculate_day_hire);
            this.groupBox2.Controls.Add(this.Total_cost);
            this.groupBox2.Controls.Add(this.txt_total_cost);
            this.groupBox2.Location = new System.Drawing.Point(564, 361);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(408, 200);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Teal;
            this.btn_close.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.Location = new System.Drawing.Point(158, 157);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(99, 37);
            this.btn_close.TabIndex = 40;
            this.btn_close.Text = "close";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_calculate_day_hire
            // 
            this.btn_calculate_day_hire.BackColor = System.Drawing.Color.Olive;
            this.btn_calculate_day_hire.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate_day_hire.Location = new System.Drawing.Point(125, 82);
            this.btn_calculate_day_hire.Name = "btn_calculate_day_hire";
            this.btn_calculate_day_hire.Size = new System.Drawing.Size(199, 37);
            this.btn_calculate_day_hire.TabIndex = 39;
            this.btn_calculate_day_hire.Text = "calculate_day_hire";
            this.btn_calculate_day_hire.UseVisualStyleBackColor = false;
            this.btn_calculate_day_hire.Click += new System.EventHandler(this.btn_calculate_day_hire_Click);
            // 
            // Total_cost
            // 
            this.Total_cost.AutoSize = true;
            this.Total_cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_cost.Location = new System.Drawing.Point(17, 36);
            this.Total_cost.Name = "Total_cost";
            this.Total_cost.Size = new System.Drawing.Size(105, 24);
            this.Total_cost.TabIndex = 26;
            this.Total_cost.Text = "Total_cost";
            // 
            // txt_total_cost
            // 
            this.txt_total_cost.Location = new System.Drawing.Point(224, 36);
            this.txt_total_cost.Name = "txt_total_cost";
            this.txt_total_cost.Size = new System.Drawing.Size(147, 20);
            this.txt_total_cost.TabIndex = 25;
            // 
            // drive_time
            // 
            this.drive_time.AutoSize = true;
            this.drive_time.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.drive_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drive_time.Location = new System.Drawing.Point(386, 7);
            this.drive_time.Name = "drive_time";
            this.drive_time.Size = new System.Drawing.Size(161, 42);
            this.drive_time.TabIndex = 31;
            this.drive_time.Text = "day tour";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1049, 647);
            this.Controls.Add(this.drive_time);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.meter_reading);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.package_details);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.package_details.ResumeLayout(false);
            this.package_details.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.meter_reading.ResumeLayout(false);
            this.meter_reading.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox package_details;
        private System.Windows.Forms.TextBox txt_package_rate;
        private System.Windows.Forms.TextBox txt_package_type;
        private System.Windows.Forms.TextBox txt_package_id;
        private System.Windows.Forms.Label package_rate;
        private System.Windows.Forms.Label package_type;
        private System.Windows.Forms.Label package_id;
        private System.Windows.Forms.TextBox txt_maximum_km;
        private System.Windows.Forms.Label maximum_km;
        private System.Windows.Forms.Label extra_hours_rate;
        private System.Windows.Forms.Label extra_km_rate;
        private System.Windows.Forms.Label maximum_hours;
        private System.Windows.Forms.TextBox txt_maximum_hours;
        private System.Windows.Forms.TextBox txt_extra_hours_rate;
        private System.Windows.Forms.TextBox txt_extra_km_rate;
        private System.Windows.Forms.Button btn_calculate_hours;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DateTimePicker end_time_date_time_picker;
        private System.Windows.Forms.DateTimePicker start_time_date_time_picker;
        private System.Windows.Forms.Label extra_hours_charge;
        private System.Windows.Forms.Label extra_hours;
        private System.Windows.Forms.Label number_of_hours;
        private System.Windows.Forms.Label end_time;
        private System.Windows.Forms.Label star_time;
        private System.Windows.Forms.TextBox txt_extra_hours_charge;
        private System.Windows.Forms.TextBox txt_extra_hours;
        private System.Windows.Forms.TextBox txt_number_of_hours;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.GroupBox meter_reading;
        private System.Windows.Forms.TextBox txt_extra_km_charge;
        private System.Windows.Forms.Label extra_km_charge;
        private System.Windows.Forms.TextBox txt_extra_km;
        private System.Windows.Forms.Label extra_km;
        private System.Windows.Forms.TextBox txt_number_of_km;
        private System.Windows.Forms.TextBox txt_end_km_reading;
        private System.Windows.Forms.TextBox txt_start_km_reading;
        private System.Windows.Forms.Label number_of_km;
        private System.Windows.Forms.Label end_km_reading;
        private System.Windows.Forms.Label start_km_reading;
        private System.Windows.Forms.Button btn_calculate_km;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btn_calculate_day_hire;
        private System.Windows.Forms.Label Total_cost;
        private System.Windows.Forms.TextBox txt_total_cost;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Label drive_time;
    }
}