﻿namespace WindowsFormsApplication3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.details = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_rate_per_month = new System.Windows.Forms.TextBox();
            this.rate_per_month = new System.Windows.Forms.Label();
            this.txt_driver_rate = new System.Windows.Forms.TextBox();
            this.txt_rate_per_week = new System.Windows.Forms.TextBox();
            this.txt_rate_per_day = new System.Windows.Forms.TextBox();
            this.txt_vehicle_models = new System.Windows.Forms.TextBox();
            this.txt_vehicle_type = new System.Windows.Forms.TextBox();
            this.txt_vehicle_number = new System.Windows.Forms.TextBox();
            this.driver_rate = new System.Windows.Forms.Label();
            this.rate_per_week = new System.Windows.Forms.Label();
            this.rate_per_day = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.vehicle_type = new System.Windows.Forms.Label();
            this.vehicle_num = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.calculate_total_cost = new System.Windows.Forms.GroupBox();
            this.txt_months = new System.Windows.Forms.TextBox();
            this.txt_weeks = new System.Windows.Forms.TextBox();
            this.txt_days = new System.Windows.Forms.TextBox();
            this.txt_total_days = new System.Windows.Forms.TextBox();
            this.chk_with_driver = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Months = new System.Windows.Forms.Label();
            this.Days = new System.Windows.Forms.Label();
            this.Weeks = new System.Windows.Forms.Label();
            this.Total_cost = new System.Windows.Forms.Label();
            this.Total_days = new System.Windows.Forms.Label();
            this.btn_calculate_days = new System.Windows.Forms.Button();
            this.returned_date_time_picker = new System.Windows.Forms.DateTimePicker();
            this.txt_total_cost = new System.Windows.Forms.TextBox();
            this.rented_date_time_picker = new System.Windows.Forms.DateTimePicker();
            this.return_date = new System.Windows.Forms.Label();
            this.rented_date = new System.Windows.Forms.Label();
            this.rate_details = new System.Windows.Forms.Label();
            this.drive_time = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.calculate_total_cost.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.details);
            this.groupBox1.Controls.Add(this.btn_search);
            this.groupBox1.Controls.Add(this.txt_rate_per_month);
            this.groupBox1.Controls.Add(this.rate_per_month);
            this.groupBox1.Controls.Add(this.txt_driver_rate);
            this.groupBox1.Controls.Add(this.txt_rate_per_week);
            this.groupBox1.Controls.Add(this.txt_rate_per_day);
            this.groupBox1.Controls.Add(this.txt_vehicle_models);
            this.groupBox1.Controls.Add(this.txt_vehicle_type);
            this.groupBox1.Controls.Add(this.txt_vehicle_number);
            this.groupBox1.Controls.Add(this.driver_rate);
            this.groupBox1.Controls.Add(this.rate_per_week);
            this.groupBox1.Controls.Add(this.rate_per_day);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.vehicle_type);
            this.groupBox1.Controls.Add(this.vehicle_num);
            this.groupBox1.Location = new System.Drawing.Point(12, 102);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(465, 481);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // details
            // 
            this.details.AutoSize = true;
            this.details.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.details.Location = new System.Drawing.Point(172, 16);
            this.details.Name = "details";
            this.details.Size = new System.Drawing.Size(100, 31);
            this.details.TabIndex = 18;
            this.details.Text = "details";
            // 
            // btn_search
            // 
            this.btn_search.BackColor = System.Drawing.Color.Teal;
            this.btn_search.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(178, 419);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(94, 37);
            this.btn_search.TabIndex = 17;
            this.btn_search.Text = "search";
            this.btn_search.UseVisualStyleBackColor = false;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txt_rate_per_month
            // 
            this.txt_rate_per_month.Location = new System.Drawing.Point(287, 276);
            this.txt_rate_per_month.Name = "txt_rate_per_month";
            this.txt_rate_per_month.Size = new System.Drawing.Size(147, 20);
            this.txt_rate_per_month.TabIndex = 16;
            // 
            // rate_per_month
            // 
            this.rate_per_month.AutoSize = true;
            this.rate_per_month.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rate_per_month.Location = new System.Drawing.Point(48, 270);
            this.rate_per_month.Name = "rate_per_month";
            this.rate_per_month.Size = new System.Drawing.Size(177, 25);
            this.rate_per_month.TabIndex = 15;
            this.rate_per_month.Text = "rate_per_month";
            // 
            // txt_driver_rate
            // 
            this.txt_driver_rate.Location = new System.Drawing.Point(287, 313);
            this.txt_driver_rate.Name = "txt_driver_rate";
            this.txt_driver_rate.Size = new System.Drawing.Size(147, 20);
            this.txt_driver_rate.TabIndex = 9;
            // 
            // txt_rate_per_week
            // 
            this.txt_rate_per_week.Location = new System.Drawing.Point(287, 241);
            this.txt_rate_per_week.Name = "txt_rate_per_week";
            this.txt_rate_per_week.Size = new System.Drawing.Size(147, 20);
            this.txt_rate_per_week.TabIndex = 10;
            // 
            // txt_rate_per_day
            // 
            this.txt_rate_per_day.Location = new System.Drawing.Point(287, 205);
            this.txt_rate_per_day.Name = "txt_rate_per_day";
            this.txt_rate_per_day.Size = new System.Drawing.Size(147, 20);
            this.txt_rate_per_day.TabIndex = 11;
            // 
            // txt_vehicle_models
            // 
            this.txt_vehicle_models.Location = new System.Drawing.Point(287, 166);
            this.txt_vehicle_models.Name = "txt_vehicle_models";
            this.txt_vehicle_models.Size = new System.Drawing.Size(147, 20);
            this.txt_vehicle_models.TabIndex = 12;
            // 
            // txt_vehicle_type
            // 
            this.txt_vehicle_type.Location = new System.Drawing.Point(287, 131);
            this.txt_vehicle_type.Name = "txt_vehicle_type";
            this.txt_vehicle_type.Size = new System.Drawing.Size(147, 20);
            this.txt_vehicle_type.TabIndex = 13;
            // 
            // txt_vehicle_number
            // 
            this.txt_vehicle_number.Location = new System.Drawing.Point(287, 91);
            this.txt_vehicle_number.Name = "txt_vehicle_number";
            this.txt_vehicle_number.Size = new System.Drawing.Size(147, 20);
            this.txt_vehicle_number.TabIndex = 14;
            // 
            // driver_rate
            // 
            this.driver_rate.AutoSize = true;
            this.driver_rate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.driver_rate.Location = new System.Drawing.Point(48, 307);
            this.driver_rate.Name = "driver_rate";
            this.driver_rate.Size = new System.Drawing.Size(126, 25);
            this.driver_rate.TabIndex = 3;
            this.driver_rate.Text = "driver_rate";
            // 
            // rate_per_week
            // 
            this.rate_per_week.AutoSize = true;
            this.rate_per_week.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rate_per_week.Location = new System.Drawing.Point(48, 235);
            this.rate_per_week.Name = "rate_per_week";
            this.rate_per_week.Size = new System.Drawing.Size(167, 25);
            this.rate_per_week.TabIndex = 4;
            this.rate_per_week.Text = "rate_per_week";
            // 
            // rate_per_day
            // 
            this.rate_per_day.AutoSize = true;
            this.rate_per_day.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rate_per_day.Location = new System.Drawing.Point(48, 199);
            this.rate_per_day.Name = "rate_per_day";
            this.rate_per_day.Size = new System.Drawing.Size(151, 25);
            this.rate_per_day.TabIndex = 5;
            this.rate_per_day.Text = "rate_per_day";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(48, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(175, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "vehicle_models";
            // 
            // vehicle_type
            // 
            this.vehicle_type.AutoSize = true;
            this.vehicle_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_type.Location = new System.Drawing.Point(48, 125);
            this.vehicle_type.Name = "vehicle_type";
            this.vehicle_type.Size = new System.Drawing.Size(145, 25);
            this.vehicle_type.TabIndex = 7;
            this.vehicle_type.Text = "vehicle_type";
            // 
            // vehicle_num
            // 
            this.vehicle_num.AutoSize = true;
            this.vehicle_num.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicle_num.Location = new System.Drawing.Point(48, 91);
            this.vehicle_num.Name = "vehicle_num";
            this.vehicle_num.Size = new System.Drawing.Size(144, 25);
            this.vehicle_num.TabIndex = 8;
            this.vehicle_num.Text = "vehicle_num";
            // 
            // calculate_total_cost
            // 
            this.calculate_total_cost.Controls.Add(this.txt_months);
            this.calculate_total_cost.Controls.Add(this.txt_weeks);
            this.calculate_total_cost.Controls.Add(this.txt_days);
            this.calculate_total_cost.Controls.Add(this.txt_total_days);
            this.calculate_total_cost.Controls.Add(this.chk_with_driver);
            this.calculate_total_cost.Controls.Add(this.button1);
            this.calculate_total_cost.Controls.Add(this.Months);
            this.calculate_total_cost.Controls.Add(this.Days);
            this.calculate_total_cost.Controls.Add(this.Weeks);
            this.calculate_total_cost.Controls.Add(this.Total_cost);
            this.calculate_total_cost.Controls.Add(this.Total_days);
            this.calculate_total_cost.Controls.Add(this.btn_calculate_days);
            this.calculate_total_cost.Controls.Add(this.returned_date_time_picker);
            this.calculate_total_cost.Controls.Add(this.txt_total_cost);
            this.calculate_total_cost.Controls.Add(this.rented_date_time_picker);
            this.calculate_total_cost.Controls.Add(this.return_date);
            this.calculate_total_cost.Controls.Add(this.rented_date);
            this.calculate_total_cost.Controls.Add(this.rate_details);
            this.calculate_total_cost.Location = new System.Drawing.Point(533, 77);
            this.calculate_total_cost.Name = "calculate_total_cost";
            this.calculate_total_cost.Size = new System.Drawing.Size(451, 481);
            this.calculate_total_cost.TabIndex = 0;
            this.calculate_total_cost.TabStop = false;
            this.calculate_total_cost.Text = "groupBox1";
            // 
            // txt_months
            // 
            this.txt_months.Location = new System.Drawing.Point(232, 347);
            this.txt_months.Name = "txt_months";
            this.txt_months.Size = new System.Drawing.Size(147, 20);
            this.txt_months.TabIndex = 29;
            // 
            // txt_weeks
            // 
            this.txt_weeks.Location = new System.Drawing.Point(231, 307);
            this.txt_weeks.Name = "txt_weeks";
            this.txt_weeks.Size = new System.Drawing.Size(147, 20);
            this.txt_weeks.TabIndex = 26;
            // 
            // txt_days
            // 
            this.txt_days.Location = new System.Drawing.Point(232, 275);
            this.txt_days.Name = "txt_days";
            this.txt_days.Size = new System.Drawing.Size(147, 20);
            this.txt_days.TabIndex = 27;
            // 
            // txt_total_days
            // 
            this.txt_total_days.Location = new System.Drawing.Point(219, 158);
            this.txt_total_days.Name = "txt_total_days";
            this.txt_total_days.Size = new System.Drawing.Size(147, 20);
            this.txt_total_days.TabIndex = 28;
            // 
            // chk_with_driver
            // 
            this.chk_with_driver.AutoSize = true;
            this.chk_with_driver.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chk_with_driver.Location = new System.Drawing.Point(232, 374);
            this.chk_with_driver.Name = "chk_with_driver";
            this.chk_with_driver.Size = new System.Drawing.Size(130, 28);
            this.chk_with_driver.TabIndex = 25;
            this.chk_with_driver.Text = "with_driver";
            this.chk_with_driver.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Olive;
            this.button1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(231, 408);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(182, 37);
            this.button1.TabIndex = 17;
            this.button1.Text = "calculate_total_cost";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Months
            // 
            this.Months.AutoSize = true;
            this.Months.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Months.Location = new System.Drawing.Point(11, 347);
            this.Months.Name = "Months";
            this.Months.Size = new System.Drawing.Size(78, 24);
            this.Months.TabIndex = 23;
            this.Months.Text = "Months";
            // 
            // Days
            // 
            this.Days.AutoSize = true;
            this.Days.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Days.Location = new System.Drawing.Point(11, 276);
            this.Days.Name = "Days";
            this.Days.Size = new System.Drawing.Size(55, 24);
            this.Days.TabIndex = 24;
            this.Days.Text = "Days";
            // 
            // Weeks
            // 
            this.Weeks.AutoSize = true;
            this.Weeks.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Weeks.Location = new System.Drawing.Point(11, 313);
            this.Weeks.Name = "Weeks";
            this.Weeks.Size = new System.Drawing.Size(73, 24);
            this.Weeks.TabIndex = 23;
            this.Weeks.Text = "Weeks";
            // 
            // Total_cost
            // 
            this.Total_cost.AutoSize = true;
            this.Total_cost.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_cost.Location = new System.Drawing.Point(25, 451);
            this.Total_cost.Name = "Total_cost";
            this.Total_cost.Size = new System.Drawing.Size(105, 24);
            this.Total_cost.TabIndex = 24;
            this.Total_cost.Text = "Total_cost";
            // 
            // Total_days
            // 
            this.Total_days.AutoSize = true;
            this.Total_days.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total_days.Location = new System.Drawing.Point(76, 167);
            this.Total_days.Name = "Total_days";
            this.Total_days.Size = new System.Drawing.Size(110, 24);
            this.Total_days.TabIndex = 24;
            this.Total_days.Text = "Total_days";
            // 
            // btn_calculate_days
            // 
            this.btn_calculate_days.BackColor = System.Drawing.Color.Olive;
            this.btn_calculate_days.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate_days.Location = new System.Drawing.Point(232, 205);
            this.btn_calculate_days.Name = "btn_calculate_days";
            this.btn_calculate_days.Size = new System.Drawing.Size(146, 37);
            this.btn_calculate_days.TabIndex = 22;
            this.btn_calculate_days.Text = "calculate_days";
            this.btn_calculate_days.UseVisualStyleBackColor = false;
            this.btn_calculate_days.Click += new System.EventHandler(this.btn_calculate_days_Click);
            // 
            // returned_date_time_picker
            // 
            this.returned_date_time_picker.Location = new System.Drawing.Point(232, 127);
            this.returned_date_time_picker.Name = "returned_date_time_picker";
            this.returned_date_time_picker.Size = new System.Drawing.Size(200, 20);
            this.returned_date_time_picker.TabIndex = 21;
            // 
            // txt_total_cost
            // 
            this.txt_total_cost.Location = new System.Drawing.Point(232, 451);
            this.txt_total_cost.Name = "txt_total_cost";
            this.txt_total_cost.Size = new System.Drawing.Size(147, 20);
            this.txt_total_cost.TabIndex = 13;
            // 
            // rented_date_time_picker
            // 
            this.rented_date_time_picker.Location = new System.Drawing.Point(232, 88);
            this.rented_date_time_picker.Name = "rented_date_time_picker";
            this.rented_date_time_picker.Size = new System.Drawing.Size(200, 20);
            this.rented_date_time_picker.TabIndex = 21;
            // 
            // return_date
            // 
            this.return_date.AutoSize = true;
            this.return_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.return_date.Location = new System.Drawing.Point(50, 125);
            this.return_date.Name = "return_date";
            this.return_date.Size = new System.Drawing.Size(116, 24);
            this.return_date.TabIndex = 20;
            this.return_date.Text = "return_date";
            // 
            // rented_date
            // 
            this.rented_date.AutoSize = true;
            this.rented_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rented_date.Location = new System.Drawing.Point(50, 86);
            this.rented_date.Name = "rented_date";
            this.rented_date.Size = new System.Drawing.Size(121, 24);
            this.rented_date.TabIndex = 20;
            this.rented_date.Text = "rented_date";
            // 
            // rate_details
            // 
            this.rate_details.AutoSize = true;
            this.rate_details.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rate_details.Location = new System.Drawing.Point(176, 16);
            this.rate_details.Name = "rate_details";
            this.rate_details.Size = new System.Drawing.Size(178, 31);
            this.rate_details.TabIndex = 19;
            this.rate_details.Text = "Rate_details";
            // 
            // drive_time
            // 
            this.drive_time.AutoSize = true;
            this.drive_time.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.drive_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drive_time.Location = new System.Drawing.Point(382, 19);
            this.drive_time.Name = "drive_time";
            this.drive_time.Size = new System.Drawing.Size(148, 42);
            this.drive_time.TabIndex = 19;
            this.drive_time.Text = "rent cal";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(996, 585);
            this.Controls.Add(this.drive_time);
            this.Controls.Add(this.calculate_total_cost);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.calculate_total_cost.ResumeLayout(false);
            this.calculate_total_cost.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox calculate_total_cost;
        private System.Windows.Forms.TextBox txt_rate_per_month;
        private System.Windows.Forms.Label rate_per_month;
        private System.Windows.Forms.TextBox txt_driver_rate;
        private System.Windows.Forms.TextBox txt_rate_per_week;
        private System.Windows.Forms.TextBox txt_rate_per_day;
        private System.Windows.Forms.TextBox txt_vehicle_models;
        private System.Windows.Forms.TextBox txt_vehicle_type;
        private System.Windows.Forms.TextBox txt_vehicle_number;
        private System.Windows.Forms.Label driver_rate;
        private System.Windows.Forms.Label rate_per_week;
        private System.Windows.Forms.Label rate_per_day;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label vehicle_type;
        private System.Windows.Forms.Label vehicle_num;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.Label details;
        private System.Windows.Forms.Label return_date;
        private System.Windows.Forms.Label rented_date;
        private System.Windows.Forms.Label rate_details;
        private System.Windows.Forms.Label drive_time;
        private System.Windows.Forms.Button btn_calculate_days;
        private System.Windows.Forms.DateTimePicker returned_date_time_picker;
        private System.Windows.Forms.DateTimePicker rented_date_time_picker;
        private System.Windows.Forms.Label Months;
        private System.Windows.Forms.Label Days;
        private System.Windows.Forms.Label Weeks;
        private System.Windows.Forms.Label Total_days;
        private System.Windows.Forms.CheckBox chk_with_driver;
        private System.Windows.Forms.Label Total_cost;
        private System.Windows.Forms.TextBox txt_total_cost;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_weeks;
        private System.Windows.Forms.TextBox txt_days;
        private System.Windows.Forms.TextBox txt_total_days;
        private System.Windows.Forms.TextBox txt_months;
    }
}