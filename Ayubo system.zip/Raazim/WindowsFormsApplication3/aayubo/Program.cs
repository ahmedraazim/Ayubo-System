﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace aayubo
{
    class aayubo
    {
        SqlConnection con = new SqlConnection("Data Source=LAB02-PC08;Initial Catalog=aayubo;Integrated Security=True");

        public void renCul(string rnumber, DateTime rented, DateTime returned, Boolean withdr)
        {
            double totrent;
            TimeSpan remaindate;
            int totdays, month, week, days, remider;
            double day_rate, week_rate, month_rate, drirate, gap;

            remaindate = returned - rented;
            gap = remaindate.TotalDays;
            totdays = Convert.ToInt16(gap);

            month = totdays / 30;
            remider = totdays % 30;
            week = totdays / 7;
            days = remider % 7;

            Console.WriteLine("Total no of days elapsed:" + totdays);
            Console.WriteLine("no of month :" + month);
            Console.WriteLine("no of week:" + week);
            Console.WriteLine("no of days:" + days);

            string sqlsearch = "select *from  Vehicle where Vehicle_Number='" + rnumber + "'";
            SqlCommand cmd = new SqlCommand(sqlsearch, con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                day_rate = Convert.ToDouble(dr["Rate_Per_Day"]);
                week_rate = Convert.ToDouble(dr["Rate_Per_Week"]);
                month_rate = Convert.ToDouble(dr["Rate_Per_Month"]);
                drirate = Convert.ToDouble(dr["Driver_Rate"]);
                totrent = month * month_rate + week * week_rate + days * day_rate;

                if (withdr == true)
                {
                    totrent = totrent + totdays * day_rate;
                }
                Console.WriteLine("Total rent :" + totrent);
            }
            else
            {
                Console.WriteLine("Vehicle not found:");

            }
            Console.ReadLine();
        }


    }

}



namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string vno, ans;
            DateTime start_Date, end_Date;
            Boolean driver;
            Console.WriteLine("Enter Vehicle no:");
            vno = Console.ReadLine();
            Console.WriteLine("Enter start Date");
            start_Date = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("End Date");
            end_Date = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Do you Need Driver?(Y/N");
            ans = Console.ReadLine();
            if (ans == "Y")
                driver = true;
            else
                driver = false;
            aayubo h1 = new aayubo();
            h1.renCul(vno, start_Date, end_Date, driver);
        }
    }
}

        